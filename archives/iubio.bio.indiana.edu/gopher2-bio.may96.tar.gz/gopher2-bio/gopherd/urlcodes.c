/* htmlcodes.c */

/* subroutines from Lynx for url encode/decode */

/*		Escape undesirable characters using %		HTEscape()
**		-------------------------------------
**
**	This function takes a pointer to a string in which
**	some characters may be unacceptable unescaped.
**	It returns a string which has these characters
**	represented by a '%' character followed by two hex digits.
**
**	In the tradition of being conservative in what you do and liberal
**	in what you accept, we encode some characters which in fact are
**	allowed in URLs unencoded -- so DON'T use the table below for
**	parsing! 
**
**	Unlike HTUnEscape(), this routine returns a malloced string.
**
*/

/* masks for URLEncodeChars */
#define     kAlphaChars	    1 
#define 		kAlphaPlusChars  2 
#define 		kPathChars       4 
#define 		HEX_ESCAPE     '%' 
 
	
static unsigned char isAcceptable[96] =
/* Overencodes */
/*	Bit 0		alphaChars		-- see HTFile.h
**	Bit 1		alphaPlusChars -- as alphaChars but with plus.
**	Bit 2 ...	pathChars		-- as alphaPlusChars but with /
*/
/* 0 1 2 3 4 5 6 7 8 9 A B C D E F */
{  0,0,0,0,0,0,0,0,0,0,7,6,0,7,7,4,	/* 2x   !"#$%&'()*+,-./	 */
	 7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,0,	/* 3x  0123456789:;<=>?	 */
	 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,	/* 4x  @ABCDEFGHIJKLMNO  */
	 7,7,7,7,7,7,7,7,7,7,7,0,0,0,0,7,	/* 5X  PQRSTUVWXYZ[\]^_	 */
	 0,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,	/* 6x  `abcdefghijklmno	 */
	 7,7,7,7,7,7,7,7,7,7,7,0,0,0,0,0 };	/* 7X  pqrstuvwxyz{\}~	DEL */

#define OKAYCHAR(a,mask)	( a>=32 && a<128 && ((isAcceptable[a-32]) & mask))

char* URLEncodeChars( const char* str, unsigned char mask)
{
	static char *hexchars = "0123456789ABCDEF";
  const char * p;
  char * q;
  char * result;
  int unacceptable = 0;

  for (p=str; *p; p++)
 		if (!OKAYCHAR( (unsigned char)*p, mask)) 
			unacceptable++;
  result = (char *) malloc( p - str + unacceptable + unacceptable + 1);
  if (result == 0) return "";

  for (q=result, p=str; *p; p++) {
  	unsigned char a = *p;
		if (!OKAYCHAR(a, mask)) {
    	*q++ = HEX_ESCAPE;	
    	*q++ = hexchars[a >> 4];
    	*q++ = hexchars[a & 15];
			}
		else *q++ = *p;
  	}
  *q++ = 0;			
  return result;
}


/*		Decode %xx escaped characters			HTUnEscape()
**		-----------------------------
**
**	This function takes a pointer to a string in which some
**	characters may have been encoded in %xy form, where xy is
**	the acsii hex code for character 16x+y.
**	The string is converted in place, as it will never grow.
*/

static char from_hex(char c)
{
    return  c >= '0' && c <= '9' ?  c - '0' 
    	    : c >= 'A' && c <= 'F'? c - 'A' + 10
    	    : c - 'a' + 10;	 
}


char* URLDecodeChars( char * str)
{
  char * p = str;
  char * q = str;

  if (!str) return "";
  while(*p) {
   	if (*p == HEX_ESCAPE) {
    	p++;
    	if (*p) *q  = from_hex(*p++) * 16;
   	  if (*p) *q += from_hex(*p++);
      q++;
			} 
   else 
		*q++ = *p++; 
	 }
  *q++ = 0;
  return str;
} 
