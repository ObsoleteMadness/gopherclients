#define LOGLOTS 1
/********************************************************************
 * lindner
 * 3.85
 * 1994/04/13 04:17:57
 * /home/mudhoney/GopherSrc/CVS/gopher+/gopherd/gopherd.c,v
 * Exp
 *
 * Paul Lindner, University of Minnesota CIS.
 *
 * Copyright 1991, 1992 by the Regents of the University of Minnesota
 * see the file "Copyright" in the distribution for conditions of use.
 *********************************************************************
 * MODULE: gopherd.c
 * Routines to implement the gopher server.
 *********************************************************************/


/* Originally derived from an 
 * Example of server using TCP protocol
 * pp 284-5 Stevens UNIX Network Programming
 */

#include <stdio.h>
#include "gopherd.h"
#include "command.h"
#include "patchlevel.h"
#include "Malloc.h"
#include "Debug.h"
#include "fileio.h"

#undef stat /** Stupid openers thing..**/

GopherDirObj *GDfromSelstr();
GopherDirObj *GDfromUFS();
void         item_info();

/******* Global variables *********/

static	char*	Gdefusername = NULL;
static  uid_t   Guid;
static  gid_t   Ggid;
static  int     NUMgopherds = -1;
static  int     HTMLit   = 0;

#define gnewline "\r\n"
#define gEOTstring ".\r\n"
#define hnewline "\n"
#define hEOTstring "\n"

char*   netline = gnewline;
char*   EOTstring = gEOTstring;

/* #define HTTPServerHeader "HTTP/1.0 200 OK\nDate: Saturday, 13-May-95 01:25:24 GMT\nServer: GopherHTTP2-dg9\nMIME-version: 1.0\n" */
#define HTTPServerHeader "HTTP/1.0 200 OK\nServer: GoHyd2-dgg\n"
char*   htmlver;
char	gWantSort = 1;


/**********************************/


extern char *getdesc();
extern double maxload;
int Process_Side();

#include "STAarray.h"
#include "STRstring.h"
#include "Sockets.h"

/* This function is called on a read timeout from the network */

#include <setjmp.h>
jmp_buf env;

SIGRETTYPE read_timeout(sig)
  int sig;
{
     longjmp(env,1);
}

void
gopherd_usage(progname) 
  char *progname;
{
     fprintf(stderr, "Usage: %s [-mCDIc] [-u username] [-s securityfile] [-l logfile] [ -L loadavg ] <datadirectory> <port>\n", progname);
     fprintf(stderr, "   -C  turns caching off\n");
     fprintf(stderr, "   -W  turns cache writing off\n");
     fprintf(stderr, "   -H  turns on HTTP server face\n");
     fprintf(stderr, "   -D  enables copious debugging info\n");
     fprintf(stderr, "   -I  enable \"inetd\" mode\n");
     fprintf(stderr, "   -c  disable chroot(), use secure open routines instead\n");
     fprintf(stderr, "   -u  specifies the username for use with -c\n");
     fprintf(stderr, "   -o  override the default options file '%s'\n", CONF_FILE);
     fprintf(stderr, "   -l  specifies the name of a logfile\n");
     fprintf(stderr, "   -L  specifies maximum load to run at\n");
     fprintf(stderr, "   -m  specifies MacIndex, whatever that is\n");
     
}

void
gopherd_exit(val)
  int val;
{
     PIDdone(GDCgetPiddir(Config), (int)getpid());
     exit(val);
}

/*
 * This is for when we dump core..  Make an attempt to clean up..
 */

SIGRETTYPE 
sigabnormalexit()
{
     gopherd_exit(-1);
}


/* dgg testing... */
#define kMaxSaveEnv  100
static char* saveenv[kMaxSaveEnv+1];


void
main(argc, argv, envp)
  int 	argc;
  char 	*argv[];
  char  *envp[];
{
     int                childpid;
     int                sockfd, newsockfd;
     int                clilen;
     struct sockaddr_in cli_addr;
     boolean            OptionsRead = FALSE;
     int                i=0;
     char               tmpstr[256];
 
     /*** for getopt processing ***/
     int c;
     extern char *optarg;
     extern int optind;
     int errflag =0;


     Argv = argv;
     HTMLit= 0;  IsHTML= HTMLit;


#if 1
/* dgg save current env to make sure child processes get copy...??? */
 {
   short j;
   char *cp, *puts;
   j=0;
   do {
     cp= envp[j];
     if (cp) {
       puts= malloc(strlen(cp)+1);
       strcpy(puts,cp);
       saveenv[j]= puts;
       }
     j++;
   } while (cp && j<kMaxSaveEnv);
   saveenv[j]= NULL;
 }
#endif

#if !(defined(NeXT) || defined(_AIX) || defined (__osf__))
     /* NeXTs don't like their envp to be overwritten... */

     for (i=0; envp[i] != NULL; i++)
          ;
#endif

     if (i > 0)
	  LastArgv = envp[i - 1] + strlen(envp[i - 1]);
     else
	  LastArgv = argv[argc - 1] + strlen(argv[argc - 1]);

     pname = argv[0];

     strcpy(Data_Dir, DATA_DIRECTORY);
     err_init();	/* openlog() early - before we chroot() of course */

     /*** Check argv[0], see if we're running as gopherls, etc. ***/

     RunServer = RunLS =  FALSE;

     if (strstr(argv[0], "gopherls") != NULL) {
	  RunLS = TRUE;
     } else 
	  RunServer = TRUE;  /** Run the server by default **/

     Config = GDCnew();  /** Set up the general configuration **/
 
     while ((c = getopt(argc, argv, "HWmCDIcL:l:o:u:")) != -1)
	  switch (c) {
	  case 'D':
	       DEBUG = TRUE;
	       break;

	  case 'I':
	       RunFromInetd = TRUE;
	       break;

	  case 'C':
	       GDCsetCaching(Config, FALSE);
	       break;
	       
	  case 'W': /* dgg - no cache write, but cache read...*/
	       GDCsetCaching(Config, 3);
	       break;

	  case 'c':
	       dochroot = FALSE;
	       break;

	  case 'H':  /* dgg addition */
	       HTMLit= 1; IsHTML= HTMLit;
	       netline= hnewline; /* no \r */
	       EOTstring= hEOTstring;
	       break;

	  case 'L':  /** Load average at which to restrict usage **/
	       maxload = atof(optarg);
	       break;

	  case 'l':  /** logfile name **/
	       if (*optarg == '/' || strcasecmp(optarg, "syslog") == 0)
		    GDCsetLogfile(Config, optarg);
	       else {
		    getwd(tmpstr);
		    strcat(tmpstr, "/");
		    strcat(tmpstr, optarg);
		    
		    GDCsetLogfile(Config, tmpstr);
	       }
	       break;
	       
	  case 'o': /** option file **/
	       if (*optarg == '/')
		    GDCfromFile(Config, optarg);
	       else {
		    getwd(tmpstr);
		    strcat(tmpstr, "/");
		    strcat(tmpstr, optarg);
		    GDCfromFile(Config, tmpstr);
	       }
	       OptionsRead = TRUE;
	       break;

	  case 'u':
	       {
		    struct passwd *pw = getpwnam( optarg );
		    if ( !pw ) {
			 fprintf(stderr,
			      "Could not find user '%s' in passwd file\n",
			      optarg);
			 errflag++;
		    } else {
			 if (!(pw->pw_uid == getuid() || getuid() == 0))
			      printf("Need to be root to use -u\n"), gopherd_exit(-1);
			 
			 Gdefusername = strdup(optarg);
			 
			 Guid = pw->pw_uid;
			 Ggid = pw->pw_gid;

		    }
	       }
	       break;

	  case '?':
	  case 'h':
	       errflag++;
	       break;
	  }

     if (errflag) {
	  gopherd_usage(argv[0]);
	  gopherd_exit(-1);
     }

     if (optind < argc) {
	  strcpy(Data_Dir, argv[optind]);
	  optind++;
	  Debug("main: Setting data to Data Directory is %s\n",Data_Dir);
     } else if (RunLS)
	  strcpy(Data_Dir, "/");


#if 0
/* !! dgg -- quick hack to run different data_dir if caller is on 
   !! different IP address (using sunos trick w/ 2 ip addresses
   17 jan 95
*/
{
     struct sockaddr_in serv_addr;
     int length = sizeof(serv_addr);
     /** Try to figure out the ip address we're running on. **/

     if ((getsockname( 0, (struct sockaddr *) &serv_addr,&length) == 0) 
         && inet_addr("129.79.225.100") == serv_addr.sin_addr.s_addr) {
	  strcpy(Data_Dir, "/bio/gopher/public2/Flybase");
	}
}
#endif

     Debug("main: Data Directory is %s\n",Data_Dir);

     if (optind < argc) {
	  GopherPort = atoi(argv[optind]);
	  optind++;
	  Debug("main: Setting port to %d\n",GopherPort);
     }
     Debug("main: Port is %d\n",GopherPort);

     /** Read the options in, if not overridden **/
     if (OptionsRead == FALSE)
	  GDCfromFile(Config, CONF_FILE);

     /*** Make sure we do a tzset before doing a chroot() ***/
     tzset();
     

     if (RunLS) {
     

	  Zehostname = SOCKgetDNSname(DOMAIN_NAME, GDCgetHostname(Config));

	  GDCsetCaching(Config, FALSE);

	  fflush(stdout);
	  uchdir(Data_Dir);
	  /* chroot lines added, jdc */
 	  if (dochroot) {
	       if (chroot(Data_Dir))
		    Abortoutput(fileno(stdout), "Data_Dir dissappeared!"), gopherd_exit(-1);
	  }
	  
	  listdir(fileno(stdout), "/", FALSE, NULL, NULL);
	  gopherd_exit(0);
     }

     if (!RunFromInetd) {
	  char *cp;
	  printf("Internet Gopher Server %s.%s patch %d\n", GOPHER_MAJOR_VERSION, GOPHER_MINOR_VERSION, PATCHLEVEL);
	  printf("Copyright 1991,92,93 the Regents of the University of Minnesota\n");
	  printf("See the file 'Copyright' for conditions of use\n");
	  printf("Data directory is %s\n", Data_Dir);
	  printf("Port is %d\n", GopherPort);

	  /*** Check for weird inconsitencies, security warnings etal ***/
	  if (getuid() == 0 && Gdefusername == NULL)
	       printf("Warning! You should run the server with the -u option!\n");
	  else if (Gdefusername != NULL)
	       printf("Running as user '%s'\n", Gdefusername);
	  
	  if (dochroot == FALSE)
	       printf("Not using chroot() - be careful\n");

	  cp = GDCgetLogfile(Config);

	  if (cp && *cp != '\0')
	       printf("Logging to File %s\n", GDCgetLogfile(Config));
     }


     if (uchdir(Data_Dir)) {
	  fprintf(stderr, "Cannot change to data directory!! %s \n",Data_Dir);
	  exit(-1);
     }

     if (dochroot && getuid() != 0) {
	  fprintf(stderr, "Gopherd uses the privileged call chroot().  Please become root.\n");
	  exit(-1);
     }

     fflush(stderr);
     fflush(stdout);

     if (DEBUG == FALSE && RunFromInetd==FALSE)
	  daemon_start(TRUE);

     /** We ignore SIGUSR2, so the PID routines can "ping" us **/
     (void) signal(SIGUSR2, SIG_IGN);
     (void) signal(SIGINT, sigabnormalexit);
     (void) signal(SIGSEGV, sigabnormalexit);

     /*** Hmmm, does this look familiar? :-) ***/
     err_init();

     /** Ask the system what host we're running on **/
     Zehostname = SOCKgetDNSname(DOMAIN_NAME, GDCgetHostname(Config));
     Debug("I think your hostname is %s\n", Zehostname);

     if (RunFromInetd) {
	  /** Ask the system which port we're running on **/
	  int newport=0;
	  if ((newport =SOCKgetPort(0)) !=0)
	       GopherPort=newport;

	  /*** Do the stuff for inetd ***/

	  while(do_command(fileno(stdout))!=0);	/* process the request */
	  shutdown(fileno(stdout), 2);
	  shutdown(fileno(stdin), 2);
	  shutdown(fileno(stderr), 2);
	  fclose(stdout);
	  fclose(stdin);
	  fclose(stderr);

	  gopherd_exit(0);
     } else {
	  LOGGopher(-1, "Starting gopher server (pid %d)", getpid());
     }

     /** Set our cmd string **/

     ServerSetArgv("waiting for connection");

     /** Clean up the pid directory before using it... **/
     PIDclean(GDCgetPiddir(Config));
     

     /** Open a TCP socket (an internet stream socket **/
     sockfd = SOCKbind_to_port(GopherPort);

     listen(sockfd, 5);
     
     for ( ; ; ) {
	  /*
	   * Wait for a connection from a client process.
	   * This is an example of a concurrent server.
	   */
	  
	  clilen = sizeof(cli_addr);
	  while (1) {
	       newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,
				  &clilen);

	       if (newsockfd >= 0)
		    break;
	       else if (errno != EINTR)  /** Restart accept if we hit a
					     SIGCHLD signal..**/
		    LOGGopher(sockfd, "Client went away");
	  }
		    

	  SOCKlinger(sockfd, FALSE);

	  
	  if ( (childpid = fork()) < 0) {
	       /** Problems forking..  **/
	       writestring(sockfd, "3Problems forking!\tmoo\terror.host\t0\r\n.\r\n");
	  }
	  
	  else if (childpid == 0) {	/* Child process */
	       close(sockfd);		/* close original socket */

	       while(do_command(newsockfd)!=0);	/* process the request */
	       gopherd_exit(0);
	  }
	  /** clean up any zombie children **/
	  sig_child();

	  close(newsockfd); 		/* parent process */
     }
}




#if 1
/* dgg, new mailfile output */

#define NO_SUBJECT "<no subject>"
#define SPLIT_MAIL 1
#define SPLIT_UNKNOWN -2

#define MAX_FIELDS 10

static char legal_day[]         = "SunMonTueWedThuFriSat";
static char legal_month[]       = "JanFebMarAprMayJunJulAugSepOctNovDec";
static int  legal_numbers[]     = { 1, 31, 0, 23, 0, 59, 0, 60, 1969, 2199 };


int IsMailFromLine(line, dateline)
  char *line;     /* Line of text to be checked */
  char *dateline; /* return date, must be >= 10 chars long */
{
		enum { kSender= 0, kDay, kMonth, kDate, kHr, kMin, kSec, kYear };
		char *fields[MAX_FIELDS];
		char *sender_tail;
		register char *lp, **fp;
		register int n, i;
		
		if (strncmp(line, "From ", 5)) return SPLIT_UNKNOWN;
		
		lp = line + 5;
		/* sender day mon dd hh:mm:ss year */
		for (n = 0, fp = fields; n < MAX_FIELDS; n++) {
		    while (*lp && *lp != '\n' && isascii(*lp) && isspace(*lp)) lp++;
		    if (*lp == '\0' || *lp == '\n') break;
		    *fp++ = lp;
		    while (*lp && isascii(*lp) && !isspace(*lp))
		         if (*lp++ == ':' && (n == 4 || n == 5)) break;
		    if (n == 0) sender_tail = lp;
		}

		if (n < 8) return SPLIT_UNKNOWN;
		fp = fields;
		if (n > 9 && !isdigit(fp[7][0])) fp[7] = fp[9]; /* ... TZ DST year */
		else if (n > 8 && !isdigit(fp[7][0])) fp[7] = fp[8]; /* ... TZ year */
		
		/* read date: Mon Jul 31 16:31:15 1995 */
		fp++;
		for (i = 0; i < 21; i += 3) if (strncmp(*fp, &legal_day[i], 3) == 0) break;
		if (i == 21) return SPLIT_UNKNOWN;
		
		fp++;
		for (i = 0; i < 36; i += 3) if (strncmp(*fp, &legal_month[i], 3) == 0) break;
		if (i == 36) return SPLIT_UNKNOWN;
		
		/* day-of-month  hr:min:sec  year */
		for (i = 0; i < 10; i += 2) {
		    lp = *++fp;
		    if (!isdigit(*lp)) return SPLIT_UNKNOWN;
		    n = atoi(lp);
		    if (n < legal_numbers[i] || legal_numbers[i+1] < n) return SPLIT_UNKNOWN;
		}
		
		if (dateline) {
			/* sprintf( dateline, "%2s-%3s-%2s", fields[kDate], fields[kMonth], fields[kYear]+2); */
			strncpy(dateline, fields[kDate],2);    dateline[2]= 0;
			strncat(dateline, fields[kMonth],3);   dateline[5]= 0;
			strncat(dateline, fields[kYear]+2,2);  dateline[7]= 0;
			}
		return SPLIT_MAIL;
}

void
process_mailfile(sockfd, Mailfname)
  int sockfd;
  char *Mailfname;
{
		 enum { kMaxFrom= 20 };
     FILE       *Mailfile;
     char  Zeline[MAXLINE], outputline[MAXLINE], * MailfnameH; 
     char	 From[kMaxFrom+10], Subj[MAXLINE], Title[MAXLINE], Date[20], dateline[20];
     long       Startbyte=0, Endbyte=0, Bytecount=0;
     boolean    foundtitle = 0, foundfrom= 0;
     char       *p;
     int  			septype = SPLIT_UNKNOWN;

		 p= strchr(Mailfname,'\0') - 1;
     if (*p == '/') *p = 0; /* http fix -- dgg */


     Debug("process_mailfile %s\n",Mailfname);
     Mailfile = rfopen(Mailfname, "r");
     if ((Mailfile == NULL) || (fgets(Zeline, MAXLINE, Mailfile) == NULL)) {
          Abortoutput(sockfd, "Cannot access file");
          return;
     }

		if (HTMLit) {
       if (HTMLit > 1) {
		      writestring(sockfd, HTTPServerHeader);
		      sprintf(outputline, "Content-type: text/html%c%c",10,10);
		      writestring(sockfd, outputline);
         }
		    writestring(sockfd, "<HTML>\n<HEAD>\n");	  
		    writestring(sockfd, "</HEAD>\n<BODY><UL>\n");
			
		}

       
 		 MailfnameH= (char*) URLEncodeChars(Mailfname,4);
     septype = IsMailFromLine(Zeline, Date);
     Bytecount += strlen(Zeline);

     if (septype != SPLIT_MAIL) {
				  if (HTMLit) {
           sprintf(outputline, "<li><a href=\"http://%s:%d/%s\">%s</a>\n",
                  Zehostname, GopherPort, MailfnameH, NO_SUBJECT);
						}
					else 
          sprintf(outputline, "0%s\t%s\t%s\t%d\r\n",
                  NO_SUBJECT, Mailfname, Zehostname, GopherPort);
          if (writestring(sockfd, outputline)<0)
               gopherd_exit(-1);
          return;
	}

     /** Read through the file, finding sections **/
     while (fgets(Zeline, MAXLINE, Mailfile) != NULL) {

         if ((!foundfrom) && strncmp(Zeline,"From: ",6)==0) {
        	/* From: "Charles T. Faulkner" <ctfaulkn@utkvx.utk.edu> */
        	/* From: matlibrs@ucbeh.san.uc.edu (Robin S. Matlib of ...) */
        	/* From: Martin Warne <martin@duality.demon.co.uk> */
        	   char *cp;
        	   
             foundfrom = TRUE;
             /* trim out the white space.. */
             p = Zeline + 5;
             while ((*p == ' ') || (*p == '\t'))  p++;
             if (*p == '\n') *From= 0;
             else if ( cp= strchr(p,'(') ) {
               p= ++cp;
               strncpy(From,p,kMaxFrom);
               if (cp= strchr( From, ')') ) *cp= 0;
             	 }
             else strncpy(From,p,kMaxFrom);
             From[kMaxFrom]= 0;
             ZapCRLF(From);
             Debug("Found from %s\n", From);
      		} 

         if (!foundtitle) {
          if (strncmp(Zeline,"Subject: ",9)==0) {
               foundtitle = TRUE;
               /* trim out the white space.. */
               p = Zeline + 8;
               while ((*p == ' ') || (*p == '\t'))  p++;
               if (*p == '\n')  strcpy(Subj, NO_SUBJECT);
               else strcpy(Subj,p);
               ZapCRLF(Subj);
               Debug("Found subject %s\n", Subj);
          		} 
          else if (strcmp(Zeline, "\n")==0) {
               foundtitle = TRUE;
               strcpy(Subj, NO_SUBJECT);
        	}
          } 
      
          else if (IsMailFromLine(Zeline, dateline) == septype) {
               Endbyte = Bytecount;
							 
               if (Endbyte != 0) {
               	char* cp= Title;
               	{ sprintf(cp, "%-14s ", From); cp+=15;}
               	{ sprintf(cp, "%8s ", Date);  cp+= 9;}
              	sprintf(cp, "%s", Subj);
				        if (HTMLit) 
                  sprintf(outputline,
               "<li><a href=\"http://%s:%d/R%d-%d-%s\">%s</a>\n",
                Zehostname, GopherPort, Startbyte, Bytecount, MailfnameH, Title);
						    else
                  sprintf(outputline, "0%s\tR%d-%d-%s\t%s\t%d\r\n",
                            Title, Startbyte, Bytecount, Mailfname,
                            Zehostname, GopherPort);
						    Debug("mail line: %s",outputline);
                if (writestring(sockfd, outputline) < 0)
                         gopherd_exit(-1);
                Startbyte=Bytecount;
                strcpy(Date, dateline);
                *From= 0; *Subj= 0;
               	}
          foundtitle = FALSE;
	  foundfrom= 0;
          }
        Bytecount += strlen(Zeline);
     	}

     if (foundtitle || foundfrom) {
	char* cp= Title;
        { sprintf(cp, "%-14s ", From); cp+=15;}
        { sprintf(cp, "%8s ", Date);  cp+= 9;}
    	sprintf(cp, "%s", Subj);
    			
	  if (HTMLit) 
       sprintf(outputline,
          "<li><a href=\"http://%s:%d/R%d-%d-%s\">%s</a>\n",
             Zehostname, GopherPort, Startbyte, Bytecount, MailfnameH, Title);
	  else
        sprintf(outputline, "0%s\tR%d-%d-%s\t%s\t%d\r\n",
                  Title, Startbyte, Bytecount, Mailfname,
                  Zehostname, GopherPort);
        if (writestring(sockfd, outputline)<0)
               gopherd_exit(-1);
        } 
	if (HTMLit) writestring(sockfd, "</UL></BODY>\n");
  Debug("Done processmail\n", 0);
  free(MailfnameH);
}

#else

#define NO_SUBJECT "<no subject>"

void
process_mailfile(sockfd, Mailfname)
  int sockfd;
  char *Mailfname;
{
     FILE *Mailfile;
     char Zeline[MAXLINE];
     char outputline[MAXLINE];
     char Title[MAXLINE];
     long Startbyte=0, Endbyte=0, Bytecount=0;
     boolean flagged = 0;
     char *p;

     Debug("process_mailfile %s\n",Mailfname);

     Mailfile = rfopen(Mailfname, "r");

     if (Mailfile == NULL) {
	  Abortoutput(sockfd, "Cannot access file");
	  return;
     }

     while (fgets(Zeline, MAXLINE, Mailfile) != NULL) {
	  if (strncmp(Zeline, "Subject: ", 9)==0 && (!flagged)) {
	       flagged =1;
	       /* trim out the white space.. */
	       p = Zeline + 8;
	       while ((*p == ' ')||(*p == '\t'))
		    p++;
	       if (*p == '\n')
		    strcpy(Title, NO_SUBJECT);
	       else
		    strcpy(Title,p);
	       
	       ZapCRLF(Title);
	       Debug("Found title %s\n", Title);
	  }
	  
	  if (strcmp(Zeline, "\n") ==0 && (!flagged)) {
	       flagged = 1;
	       strcpy(Title, NO_SUBJECT);
	       Debug("No subject found - using default\n",0);
	  }
	  
	  if (is_mail_from_line(Zeline)==0) {
	       Endbyte = Bytecount;
	       flagged =0;

	       if (Endbyte != 0) {
		    sprintf(outputline, "0%s\tR%d-%d-%s\t%s\t%d\r\n", 
			    Title, Startbyte, Bytecount, Mailfname,
			    Zehostname, GopherPort);
		    if (writestring(sockfd, outputline) < 0)
			 LOGGopher(sockfd, "Client went away"), gopherd_exit(-1);
		    Startbyte=Bytecount;
		    *Title = '\0';
	       }
	  }

	  Bytecount += strlen(Zeline);
     }

     if (*Title != '\0') {
	  sprintf(outputline, "0%s\tR%d-%d-%s\t%s\t%d\r\n", 
		  Title, Startbyte, Bytecount, Mailfname, 
		  Zehostname, GopherPort);
	  if (writestring(sockfd, outputline)<0)
	       LOGGopher(sockfd, "Client went away"),gopherd_exit(-1);
     }	  

}

#endif

/* dgg++   test if file exists (use to test for .ASK script & others) */
boolean
FileExists( pathname, extension)
  char *pathname;
  char *extension;
{
  struct stat statbuf;
  static char tmpfile[512];

  strcpy(tmpfile, pathname);
  if (extension) strcat(tmpfile, extension); 
  if (!rstat( tmpfile, &statbuf))
	  return TRUE;
  else 
	  return FALSE;
}


/*
 * Given a specific view, add the filename extension that
 * we stripped off for the multiple views stuff
 */

char *
AddExtension(cmd, view)
  CMDobj *cmd;
  char *view;
{
  char *filename = CMDgetFile(cmd);
  char *newselstr;
  int  flen=0, newlen=0;
  char *newfile;

  if (filename == NULL)  return(CMDgetSelstr(cmd));

  newfile = EXAfindFile(Config->Extensions, filename, view);
  flen = strlen(filename);
  newlen = strlen(newfile);
  if (newlen > flen) {
	  /*** Add the found extensions... ***/
	  newselstr = (char *)malloc(MAXPATHLEN);
	  strcpy(newselstr, CMDgetSelstr(cmd));
	  strcat(newselstr, newfile+flen);
    Debug("New long file is %s", newselstr);
    return(newselstr);
    }
  return(CMDgetSelstr(cmd));
}


/* dgg add */
void
HTTPputenv(cmd, method, doneCONTENT_TYPE)
  CMDobj  *cmd;
  char* method;
  boolean * doneCONTENT_TYPE;
{
	/*  add env vars from other stuff for http-cgi compliant child apps */			
  char * qp, * hp,  * tmpputenv;
  int	i;
  	
	tmpputenv = malloc(strlen(method) + 16);
	sprintf( tmpputenv, "REQUEST_METHOD=%s", method);
	putenv( tmpputenv);
	Debug("HTTP putenv: %s\n", tmpputenv);
	
	for (i=0; i < CMDnumAsklines(cmd); i++) {
	    tmpputenv= NULL;
	    qp= CMDgetAskline(cmd, i);
	    if (strncasecmp( qp, "Content-type:",13) == 0) {
		tmpputenv = malloc(strlen(qp) + 1);
	    	hp= qp+13; while(*hp && *hp<=' ') hp++;
	    	sprintf( tmpputenv, "CONTENT_TYPE=%s", hp);
	    	putenv( tmpputenv);
		*doneCONTENT_TYPE= 1;
	    	}
	    else if (strncasecmp( qp, "Content-length:",15) == 0) {
		tmpputenv = malloc(strlen(qp) + 1);
	    	hp= qp+15; while(*hp && *hp<=' ') hp++;
	    	sprintf( tmpputenv, "CONTENT_LENGTH=%s", hp);
	    	putenv( tmpputenv);
	    	}
	    else if (strncasecmp( qp, "From:",5) == 0) {
		tmpputenv = malloc(strlen(qp) + 1);
	    	hp= qp+5; while(*hp && *hp<=' ') hp++;
	    	sprintf( tmpputenv, "FROM=%s", hp);
	    	putenv( tmpputenv);
	    	}
	    else if (strncasecmp( qp, "User-agent:",11) == 0) {
		tmpputenv = malloc(strlen(qp) + 1);
	    	hp= qp+11; while(*hp && *hp<=' ') hp++;
	    	sprintf( tmpputenv, "USER_AGENT=%s", hp);
	    	putenv( tmpputenv);
		if (strncmp( hp,"Mozilla/2",9) == 0
		 || strncmp( hp,"NCSA Mosaic/3",13) == 0
		  ) {
			  /* clients that do super/subs & other HTML v.3 things */
		    htmlver= "HTML3M";
	      Debug("HTMLVER: %s\n", htmlver);
	      }
	    	}
	    else if (strncasecmp( qp, "Referer:",8) == 0) {
		tmpputenv = malloc(strlen(qp) + 1);
	    	hp= qp+8; while(*hp && *hp<=' ') hp++;
	    	sprintf( tmpputenv, "REFERER=%s", hp);
	    	putenv( tmpputenv);
	    	}
	    else if (strncasecmp( qp, "Accept:",7) == 0) {
	    	/* !! need multiple env vars or all types on on var !? */
		tmpputenv = malloc(strlen(qp) + 1);
	    	hp= qp+7; while(*hp && *hp<=' ') hp++;
	    	sprintf( tmpputenv, "ACCEPT=%s", hp);
	    	putenv( tmpputenv);
	    	}
	if (tmpputenv) Debug("HTTP putenv: %s\n", tmpputenv);
	}
	
}

/* dgg  extracted subfunc */
char*
getView(sockfd, cmd)
  int sockfd;
  CMDobj  *cmd;
{
  GopherDirObj *gd;
  int num,i;
  char * view= NULL;
  
  /** Get gopher directory containing item in question **/
  gd = GDfromSelstr(cmd, sockfd);
  if (gd != NULL) {
	num = GDSearch(gd, CMDgetSelstr(cmd));
	if (num >=0) {
	    GopherObj *gs;
	    gs= GDgetEntry(gd, num);
	
    	    /*if ((isGplus || HTMLit) && GSgplusInited(gs) == FALSE)  GSplusnew(gs);*/
	    if (GSgplusInited(gs) == FALSE) {  view = ""; }
	
	    /**  If only one view, take it **/
	    else if (GSgetNumViews(gs) == 1)
		 view = VIgetViewnLang(GSgetView(gs, 0),(char*)malloc(128));
	    else {
		 /*** Hmmm, let's choose one.. ***/
		 for (i=0; i<GSgetNumViews(gs); i++) {
		      char *tmpview;
	
		      tmpview = VIgetType(GSgetView(gs,i));
		      if (GSgetType(gs) == '0') {
			   if (strcasecmp(tmpview, "Text/plain")==0) {
				view = VIgetViewnLang(GSgetView(gs, i),(char*)malloc(128));
				break;
			   }
		      }
		      if (GSgetType(gs) == 'I') {
			   if (strcmp(tmpview, "image/gif")==0) {
				view = VIgetViewnLang(GSgetView(gs, i),(char*)malloc(128));
				break;
			   }
		      }
	
		 }
		 if (view == NULL)
		      /** Give up, take the first view... **/
		      view = VIgetViewnLang(GSgetView(gs,0), (char*)malloc(128));
	    }
	    /** We should have a view by now **/
	}
	GDdestroy(gd);
  }
  return view;
}

int EXECflag;

int
doThisCommand(sockfd, cmd)
  int sockfd;
  CMDobj  *cmd;
{
     char    logline[MAXLINE];
     char    *view     = NULL;
     char    *Selstr   = NULL;
     char    *filter   = NULL;
     char    *cp;
     char    tmpstr[256];
     int     result;
     boolean doneCONTENT_TYPE= 0;


     GDCevalDir(Config, CMDgetFile(cmd));

     /** Change our root directory **/
     if ( dochroot ) {
	  if (chroot(Data_Dir))
	       Abortoutput(sockfd, "Data_Dir dissappeared!"), gopherd_exit(-1);
	  
	  uchdir("/");	/* needed after chroot */
     }

     setgid(Ggid);
     setuid(Guid);
     EXECflag = 0;
     EXECargs = NULL;
     IsGplus = CMDisGplus(cmd);  /* need for error output.. */

#if 1
    /* dgg patch to accept queries from  http/html browsers */
    htmlver= "";
    {
     char *selp, *hp, *qp, *tmpputenv;
     char selchar= '0';
     struct stat    statbuf;
     boolean ishead = 0, isquery= 0, ispost= 0, usecgiparams= 0;
     int  i;

#if 1
     if (strncmp("HEAD ",CMDgetSelstr(cmd),5) == 0) {
       ishead= 1; HTMLit=1;   IsHTML= HTMLit;
       selp= CMDgetSelstr(cmd) + 5; /* skip HEAD*/
			 goto labelHandleHTTP; /* need to fix cmd/selp ... */
			}
		else
#endif

     if (strncmp("POST ",CMDgetSelstr(cmd),5) == 0) {
	    FILE *retrfile;
        ispost= 1;
        HTMLit=2;   IsHTML= HTMLit;
        selp= CMDgetSelstr(cmd) + 5;  

	     /** Write the stuff out to a file, here, as gopherd user
	      so we can remove file later on.. **/
	ASKfile = tempnam(NULL, "gdata");
	Debug("HTTP POST data is in %s\n", ASKfile);
	retrfile = ufopen(ASKfile, "w",0777);
	if (retrfile != NULL) {
			/* ?? only last line has data we want in POST ?? */
		qp= CMDgetAskline(cmd, CMDnumAsklines(cmd)-1); 
		if (!usecgiparams) {
			while ((hp= strchr(qp,'&'))!=0) *hp= ' '; 
			while ((hp= strchr(qp,'+'))!=0) *hp= ' ';
			URLDecodeChars( qp);
			}
		fputs( qp, retrfile);
		putc('\n', retrfile);
		fclose(retrfile);
       		}
	HTTPputenv( cmd, "POST", &doneCONTENT_TYPE);
	goto labelHandleHTTP;
	}
     	
     else if (strncmp("GET ",CMDgetSelstr(cmd),4) == 0) {
#if 1
	HTTPputenv( cmd, "GET", &doneCONTENT_TYPE);
#else
     	long len;
     	char inputline[512];
	   /* this loop causes telnet test to hang waiting for input... */
     	do {
	  inputline[0]= 0;
     	  len = readline(sockfd, inputline, sizeof(inputline));
        /* if(strstr(inputline,"User-agent"))  */
	if (strstr(inputline,"User-Agent: Mozilla/2")) {
		/* temp hack for mozilla's html options */
	  	htmlver= "HTML3M";
            	Debug("HTMLVER: %s\n", htmlver);
        	}
        Debug("HTTP GOT: %s\n", inputline);
     	} while (inputline[0] > ' '); /* (len>0) */
#endif
        selp= CMDgetSelstr(cmd) + 4; /* skip that GET*/
	goto labelHandleHTTP;
	}

     else if (HTMLit) {
	char* cp;
        /* generic HTTP entry */
        selp= CMDgetSelstr(cmd);
        if (*selp == '7') {
    	  char *tmpputenv;
	  tmpputenv = malloc(26);
	  sprintf(tmpputenv, "GOITEM_TYPE=text/html");
	  putenv(tmpputenv);
	  goto labelDoneHTTP; /* for gopher query mixup !?*/
	  }
#if 0
	else if (*selp != 'e' && ((cp= strstr(selp,"xec+:")) != NULL) )
    	 {
	  char newpath[256];
	  /* this is mosaic pushing gopher protocolized "exec+" */
	  /* !? missing query params in this gopher via mosaic to exec?q */
	  /*
	   if((qp= strchr(selp,'\t'))!=0) { 
             *qp='?';
	     }
	  */
	  sprintf( newpath, "e%s", cp);
	  selp= strdup(newpath);
          CMDsetSelstr(cmd,selp);
	  }
#endif

  labelHandleHTTP:        
      if (!HTMLit) HTMLit= 1;  IsHTML= HTMLit;
      if (strlen(htmlver)<1) htmlver= "HTML1";

      /* if (!usecgiparams) */
      URLDecodeChars( selp);     /* convert %HEX to normal chars */

      if (*selp == '/') selp++;  /* drop leading slash */

	/* dgg 4feb96 - try to eliminate gopher type char in http path... */
  if (selp[1]=='/') {
	if (*selp == 'm') selchar= '1';
	else if (*selp == '7') selchar= '7';
  else selchar= *selp;
      	/* if (selp[1] == '/') selp += 2; */
	  	}
  else if (*selp == 'e' && (
    selp[1] == 'a' || selp[1] == 'b' || 
    strncmp(selp,"exec+",5) == 0
    )) {
	  	selchar= *selp; /* ??? */
	  	}
  else if (*selp == 'R' && isdigit(selp[1])) {
		/* trick for "R123-456-/path/to/file" range spec */
		selchar= 'R';
		
		}
  else {
	     /* ?? add default "0/" ?? */
	    selchar= '0';
	    strcpy(tmpstr,"0/");
	    strcat(tmpstr,selp);
		selp= strdup(tmpstr);
	    CMDsetSelstr(cmd,selp);
	    }

	  /* drop  HTTP/1.x vers string */
      if ((hp= strstr(selp," HTTP")) != NULL) { *hp= 0; hp[1]=0; HTMLit = 2; }
      if ((qp= strchr(selp,'?'))!=0) {
	isquery= 1;
        *qp++= 0;  /* separate query from path selector... */
        if (1) { /*(!usecgiparams)*/
          while ((hp= strchr(qp,'&'))!=0) *hp= ' '; 
          while ((hp= strchr(qp,'+'))!=0) *hp= ' ';
          }
        CMDsetSearch(cmd, qp); 
        EXECargs = qp; 
        EXECflag = 3;
        }
        
      else if ((qp= strstr(selp,"internal-gopher")) != NULL) {
	/* have an icon request that local viewer didn't satisfy... */
	/* see if we can do it.:  newpath= "/.bin/icons/gopher-menu.gif" */
	char newpath[256];
	qp += 9; /* + strlen("internal-"); */
	sprintf( newpath, "9%s/%s.gif", GDCgetIcondir(Config), qp);
	selp= strdup(newpath);
	selchar= *selp;
        view= "image/gif";
	Debug("HTTP internal-gopher image: %s\n", selp);
	}
	
#if 1	      
      CMDsetSelstr(cmd,selp); 
      if (!rstat(CMDgetFile(cmd), &statbuf)) {
        if (S_ISDIR(statbuf.st_mode)) {
          selchar = '1';
       	  *CMDgetSelstr(cmd) = '1'; 
       	  }
        }
      /* tmpstr[0]= selchar; tmpstr[1]= 0;
        CMDsetSelstr(cmd,tmpstr); 
      */
#else
      CMDsetSelstr(cmd,selp); 
      selchar= *selp;
#endif

		if (ishead) {
				/* HEAD command */
	     item_info(cmd, sockfd);
	     return(0);
			}

      if (!view) {
 	switch (selchar) {
 	  case '1':
 	  case 'h': view= "text/html"; break; /* ! no gopher-menu views ! */
	  case 'R': view= "text/plain"; break;
	  case '7': if (!isquery) {
          if (HTMLit > 1) {
	      writestring(sockfd, HTTPServerHeader);
	      writestring(sockfd, "Content-type: text/html\n\n");
	      }
	   writestring( sockfd, "<html><head><title>Simple query</title><isindex></head>");
	   sprintf( tmpstr, "<body><h2>Search index</h2></body></html>");
	   writestring(sockfd, tmpstr);
	   return(0);
	   }
	   break;
 	  }
      	if (!view) view= getView(sockfd, cmd);
        if (!view) switch (selchar) {
      	  case '9': view= "file/binary"; break;
      	  case 'I':
      	  case 'g': view= "image/gif"; break;
          case '0': view= "text/plain"; break; /* dgg dec95 fix goph text? */
      	  default : view= "text/html"; break;
      	  }
      	 }

     	}
labelDoneHTTP:
	;
     }
#endif 


     /** at this point we can write out a pid file, so we can remove
        it later on **/

     PIDwritef(GDCgetPiddir(Config), "connection from %s\n", CurrentPeerName);

     if (!HTMLit && CMDisAskitem(cmd)) {
	  FILE *retrfile;

	  /** Write the stuff out to a file, here, as gopherd user
	      so we can remove file later on.. **/
          ASKfile = tempnam(NULL, "gdata");
          Debug("Ask data is in %s\n", ASKfile);
          retrfile = ufopen(ASKfile, "w",0777);
	  if (retrfile != NULL) {
	       int i;
	       for (i=0; i < CMDnumAsklines(cmd); i++) {
		    fputs(CMDgetAskline(cmd, i), retrfile);
                    putc('\n', retrfile);
               }
          }
	  fclose(retrfile);
     }

     /** Extract the view if it exists **/
     if (CMDgetCommand(cmd) != NULL) {
	  char *command = CMDgetCommand(cmd);
	  if (*command == '+' && strlen(command)>1)
	       view = command+1;
	  else if (*command == '!') {
	      char* selp = CMDgetSelstr(cmd);
   	    if ( strncmp(selp, "exec+",5)==0 	    
          || (*selp == 'e' && (selp[1] == 'b' || selp[1] == 'a') ) 
 	        ) {
		/* dgg patch for exec+: -- need to translate this 
	     	  exec+:params:/go/path/prog<tab>! 
	  	into calling program as this
	     	  /root/go/path/prog -v application/gopher+-menu" param
		*/
	       filter = command + 1;
	       view = "application/gopher+-menu";
	       CMDsetView(cmd, view);
	       *command = '+';
         /* CMDsetCommand(cmd, "+");  ?? or "" */
   		}
	      else {
	       item_info(cmd, sockfd);
	       if (*(command+1) != '\0')
		    filter = command + 1;
	       return(0);
				}
	  }
	  else if (*command == '$') {
	       if (*(command+1) != '\0')
		    filter = command + 1;
	       view = "application/gopher+-menu";
	       CMDsetView(cmd, view);
	       *command = '+';
	  }
	  else
	       ; /*** Error ***/
     }
     
     if (strncmp(CMDgetSelstr(cmd), "waisdocid:",10)==0)
	     view = "Text/plain";

     /*** Root level null selector string.. ***/
     if (!view && strlen(CMDgetSelstr(cmd)) == 0) 
	     view = "application/gopher-menu";


     if (!view && *CMDgetSelstr(cmd) == 'h') {
 	  /** It might be a directory..., or an HTML file on disk **/
 	  struct stat    statbuf;
 	  char  *selp;

           /*dgg, move 'h' out of exec ? */
 	  selp= CMDgetSelstr(cmd);
   	if (strncmp( selp, "hexec",5)==0) CMDsetSelstr(cmd,selp+1); 
 
 	  if (!rstat(CMDgetFile(cmd), &statbuf)) {
 	       if (S_ISDIR(statbuf.st_mode)) {
 		    /*** It's a directory capability ***/
  		    *CMDgetSelstr(cmd) = '1';
 	       }
 	  }
  	  view = "text/html";
     }

     /*** Try to speed things up for gopher0 requests, avoid reading
          big directories.. ***/

     if (!view && CMDisGplus(cmd) == FALSE) {
	     struct stat  statbuf;
	     char *cp = CMDgetSelstr(cmd);
	   
	    if (*cp == '0' || *cp == 'R') {
	       if (!rstat(CMDgetFile(cmd), &statbuf))
		      view = "text/plain";
	       }
	    else if (*cp == '1') {
	       if (!rstat(CMDgetFile(cmd), &statbuf))
		       view = "application/gopher-menu";
	       }
      }

			/* dgg patch for exec+: items ... */
		Selstr= CMDgetSelstr(cmd);
	  if (!view && 
	    strncmp(Selstr, "exec+",5)==0
      || (*Selstr == 'e' && (Selstr[1] == 'b' || Selstr[1] == 'a') ) 
	    ) {
			/* might be text, binary, folder, etc... */
			/* big hack for ?only existing binary exec+ */
			/* ! need to change server items to use bexec+: for binary exec+ ?? */
			/* and reserve exec+: for text transmission items !? */
			if (strstr(Selstr,"pickmap") != NULL
			 || (*Selstr == 'e' && Selstr[1] == 'b')
			 || strstr(Selstr,"exec+b") != NULL
			 )
				view= "file/binary";
			else 
				view= "text/plain";
			}
			
			
     if (!view) view= getView(sockfd, cmd);
     CMDsetView(cmd, view);

     /*
      * Set the environment variable CONTENT_TYPE for 
      * shell script writers everywhere..
      *
      * (Definitely needed for Type 1 support where you have
      *  application/gopher-menu and application/gopher+-menu)
      * 
      * We could put other stuff here too, if need be..
      */

#ifndef NeXT
{
     char *tmpputenv;
     if (!doneCONTENT_TYPE && view != NULL) {
	  tmpputenv = malloc(strlen(view) + 15);
	  sprintf(tmpputenv, "CONTENT_TYPE=%s", view);
	  putenv(tmpputenv);
     }

     if (CMDgetCommand(cmd) != NULL) {
	  tmpputenv = malloc(strlen(CMDgetCommand(cmd)) + 11);
	  sprintf (tmpputenv, "GPLUS_CMD=%s", CMDgetCommand(cmd));
	  putenv(tmpputenv);
     }
	/* dgg -- add SERVER_HOST, SERVER_PORT, SERVER_PATH to child env */

	  tmpputenv = malloc(13 + strlen(Zehostname));
	  sprintf (tmpputenv, "SERVER_HOST=%s", Zehostname);
	  putenv(tmpputenv);

	  tmpputenv = malloc(20);
	  sprintf (tmpputenv, "SERVER_PORT=%d", GopherPort);
	  putenv(tmpputenv);

	  tmpputenv = malloc(13 + strlen(Data_Dir));
	  sprintf (tmpputenv, "SERVER_PATH=%s", Data_Dir);
	  putenv(tmpputenv);

	  tmpputenv = malloc(13 + strlen(htmlver));
	  sprintf (tmpputenv, "HTML_VER=%s", htmlver);
	  putenv(tmpputenv);
#if 1
	/* dgg -- copy all of parent/shell env to child ! */
 {
   short j;
   char *cp, *puts;
   j=0;
   do {
     cp= saveenv[j++];
     if (cp) { 
       puts= malloc(strlen(cp)+1);
       strcpy(puts,cp);
       putenv(puts);
       }
   } while (cp && j<500);
 }
#endif

}
#endif

     /** Decide whether to add extensions of not .. **/
     if (view != NULL)
	     Selstr = AddExtension(cmd, view);
     else
	     Selstr = CMDgetSelstr(cmd);


     ServerSetArgv("%s to %s", Selstr, CurrentPeerName);
     PIDwritef(GDCgetPiddir(Config), "%s to %s\n", Selstr, CurrentPeerName);

     /* EXECflag = 0; EXECargs = NULL; */

     /*  Ask items are shell scripts, not directories.
	 Selector strings with '1/' should never be shell scripts */
	
     if (!HTMLit && CMDisAskitem(cmd) && *Selstr == '1')
	  *Selstr = '0';

     /*** With the funky new capability system we can just check the
          first letter(s), end decide what the object refers to. ***/

     switch (*Selstr) {
     case '\0':
     case '\t':

	  /*** The null capability, so it's not a file, probably wants
	       to talk to a directory server ***/

	  /*** we'll just do a "list" of the root directory, with no user
	       capability.  ***/


	  listdir(sockfd, "/", CMDisGplus(cmd), view, filter);
	  LOGGopher(sockfd, "Root Connection");
	  break;

     case 'h':
     case '0':
     case '9':
     case 's':
     case 'I':
     case 'g':
	  /*** It's some kind of file ***/

	  /*** Is it binary??  ***/
	  
	  if (view == NULL)  {
	       if (*Selstr != '0')
		    send_binary(sockfd, Selstr+1, CMDisGplus(cmd), view);
	       else
		    printfile(sockfd, Selstr+1, 0, -1, CMDisGplus(cmd), view);
	  } else {
	       if (GSisText(NULL, view))
		    printfile(sockfd, Selstr+1, 0, -1, CMDisGplus(cmd), view);
	       else
		    send_binary(sockfd, Selstr+1, CMDisGplus(cmd), view);
	  }
	  /*** Log it ***/
	  LOGGopher(sockfd, "retrieved file %s", Selstr+1 );
	  break;


     case '1':
	  /*** It's a directory capability ***/
	  listdir(sockfd, Selstr+1, CMDisGplus(cmd), view, filter);

#ifdef LOGLOTS
	  /** Log it **/
	  LOGGopher(sockfd, "retrieved directory %s", Selstr+1);
#endif
	  break;

     case '7':
	  /*** It's an index capability ***/
	  result = GDCCanSearch(Config, CurrentPeerName, CurrentPeerIP,
				NUMgopherds);

	  if (result == SITE_NOACCESS) {
	       Abortoutput(sockfd, GDCgetBummerMsg(Config));
	       LOGGopher(sockfd, "Denied access for %s", Selstr+1);
	       break;
	  } else if (result == SITE_TOOBUSY) {
	       Abortoutput(sockfd, "Sorry, too busy now...");
	       break;
	  }

#if 1
		 if (IsHTML>1) { 
		      writestring(sockfd, HTTPServerHeader);
		      writestring(sockfd, "Content-type: text/html\n\n");
				}
#endif


	  Do_IndexTrans(sockfd, Selstr+1, cmd, TRUE);

	  break;


     case 'm':
	  if (strncmp(Selstr, "mindex:", 7)==0) {
	       /*** First test for multiple indexes ***/
	       result = GDCCanSearch(Config, CurrentPeerName, CurrentPeerIP,
				NUMgopherds);

	       if (result == SITE_NOACCESS) {
		    Abortoutput(sockfd, GDCgetBummerMsg(Config));
		    LOGGopher(sockfd, "Denied access for %s", Selstr+1);
		    break;
	       } else if (result == SITE_TOOBUSY) {
		    Abortoutput(sockfd, "Sorry, too busy now...");
		    break;
	       }

	       do_mindexd(sockfd, Selstr+7, CMDgetSearch(cmd), CMDisGplus(cmd),
			  view);
	       break;
	  }


	  /*** This is an internal identifier ***/
	  /*** The m paired with an Objtype of 1 makes a mail spool file
	    into a directory.
	    ***/

	  result = GDCCanBrowse(Config, CurrentPeerName, CurrentPeerIP,
				NUMgopherds);

	  if (result == SITE_NOACCESS) {
	       Abortoutput(sockfd,  GDCgetBummerMsg(Config));
	       LOGGopher(sockfd,"Denied access for %s", Selstr+1);
	       break;
	  } else if (result == SITE_TOOBUSY) {
	       Abortoutput(sockfd, "Sorry, too busy right now..");
	       break;
	  }

	  process_mailfile(sockfd, Selstr + 1);
	  writestring(sockfd, EOTstring);  

	  /** Log it **/
	  LOGGopher(sockfd, "retrieved maildir %s", Selstr+1 );

	  break;

     case 'R':
	  /*** This is an internal identifier ***/
	  /*** The R defines a range  ****/
	  /*** The format is R<startbyte>-<endbyte>-<filename> **/
     {
	  int startbyte, endbyte;
	  char *cp, *oldcp;

	  cp = strchr(Selstr+1, '-');
	  
	  if (cp == NULL) {
	       Abortoutput(sockfd, "Range specifier error");
	       break;
	  }
	  
	  *cp = '\0';
	  startbyte = atoi(Selstr+1);
	  oldcp = cp+1;

	  cp = strchr(oldcp, '-');
	  
	  if (cp == NULL) {
	       Abortoutput(sockfd, "Range specifier error");
	       gopherd_exit(-1);
	  }

	  *cp = '\0';
	  endbyte = atoi(oldcp);
	  oldcp = cp + 1;

	  Debug("Start: %d, ", startbyte);
	  Debug("End: %d, ", endbyte);
	  Debug("File: %s\n", oldcp);

	  printfile(sockfd, oldcp, startbyte, endbyte, CMDisGplus(cmd), view);

	  /*** Log it ***/
	  LOGGopher(sockfd, "retrieved range %d - %d of file %s", startbyte, endbyte, oldcp);
	  break;
     }

     case 'f':
	  result = GDCCanFTP(Config,CurrentPeerName,CurrentPeerIP,NUMgopherds);
	  if (result == SITE_NOACCESS) {
	       Abortoutput(sockfd,  GDCgetBummerMsg(Config));
	       LOGGopher(sockfd, "Denied access for %s", Selstr);
	       break;
	  } else if (result == SITE_TOOBUSY) {
	       Abortoutput(sockfd, "Sorry, too busy now...");
	       break;
	  }

	  if (strncmp(Selstr, "ftp:",4)==0){

	       LOGGopher(sockfd, "retrieved %s", Selstr);

	       GopherFTPgw(sockfd, Selstr+4);
	       break;
	  }
	  break;

       
     case 'e':
	  result = GDCCanBrowse(Config, CurrentPeerName, CurrentPeerIP,
				NUMgopherds);

	  if (result == SITE_NOACCESS) {
	       Abortoutput(sockfd,  GDCgetBummerMsg(Config));
	       LOGGopher(sockfd,"Denied access for %s", Selstr+1);
	       break;
	  } else if (result == SITE_TOOBUSY) {
	       Abortoutput(sockfd, "Sorry, too busy right now..");
	       break;
	  }

	  if (strncmp(Selstr, "exec:", 5)==0 ) {
     /* args are between colons */
	       char *args, *command;
	       
	       command = strrchr(Selstr + 5, ':');
	       if (command == NULL)
		    break;

	       if (*(Selstr+4) == ':' && *(Selstr+5) == ':')
		    args = NULL;
	       else
		    args = Selstr+5;

	       *command = '\0';
	       command++;
	       
	       EXECargs = args;
	       EXECflag = 1;

	       printfile(sockfd, command, 0, -1, CMDisGplus(cmd), view);
	       LOGGopher(sockfd, "Executed %s %s", command,  (args == NULL)
			 ? " " : args);
	       }
	       
		else if (
		  strncmp(Selstr, "exec+", 5)==0
      ||  Selstr[1] == 'a' || Selstr[1] == 'b'
  		) {
			    /* args are between colons */
			char *args, *command, *query;
			boolean  isGplus, istext;
			short   ic;

      if (strncmp(Selstr, "exec+b",6)==0) ic= 7; 
      else if (Selstr[1] == 'a' || Selstr[1] == 'b') ic= 3;
      else ic= 6;

			istext= 0;
			command = strrchr(Selstr + ic, ':');
			if (command == NULL) break;
			if (*(Selstr+ic-1) == ':' && *(Selstr+ic) == ':') args = NULL;
			else {
				args = Selstr+ic;
				/* dgg:may96 - fix for dang http browsers that can't take spaces..
				   of course this will break any real use of '_' in args */
			  {
			  char *cp= args;
			  while (*cp && *cp != ':') {
			     if (*cp == '_') *cp= ' ';
			     cp++; 
			     }
			  }
				}
			*command = '\0';
			command++;
			
			/* dgg:jan96: patch for imagemap & others needed putenv().... */
			/* use syntax http://host/exec+b:params:pi=mapname//path/to/app?123,456 */
			/* ?? need general syntax for env vars in exec+ method ?? */
			/* this isn't needed after simple patch to imagemap.c for cmdline args */

			if (*command) {
 			char * cp, * ep;
			cp= strchr(command,'/');
			if (cp && cp[1] == '/') {
				char* eargs= command;
				*cp= 0;
				command= cp+1;
				cp= strstr(eargs,"pi=");
				if (cp) {
					char* tenv;
				  cp += 3;
          ep= cp; while (*ep > ' ') ep++;
					*ep= 0;
         	tenv = malloc(strlen(cp) + 1);
	       	sprintf( tenv, "PATH_INFO=%s", cp);
	    	  putenv( tenv);
					}
			  }
			}

		 	 /* patch for html browsers sending query as path?query */
			query= strchr(command,'?');
      if (query) *query++= 0;
#if 1
/* will this fix bug w/ gopher exec+ query ?? */
      else query= CMDgetSearch(cmd);
#endif
      if (query) {
	      long len;
	      char *newargs;
	
				if (args) {
	        len= strlen(args) + strlen(query) + 3;
	        newargs = (char *)malloc(len);
	        strcpy(newargs, args);
	        strcat(newargs, " ");
	        strcat(newargs, query); 
	        args= newargs;
	        }
	      else 
	        args= query;
		      }
	
	  	    /* dgg -- add any query/search params to args ! */
	        /* this fails: if (CMDgetSearch(cmd)) */
	      if (CMDgetSearch(cmd) || CMDgetCommand(cmd)) {
	        long len;
	        char *newargs;
	        query= "";
	        if (CMDgetSearch(cmd)) query= CMDgetSearch(cmd);
	        else query= CMDgetCommand(cmd);
	        if (query && (*query == '!' || *query == '$' )) {
	          query= "-v application/gopher+-menu";
			      istext= 1;
			      }
		      if (args) {
		        len= strlen(args) + strlen(query) + 3;
		        newargs = (char *)malloc(len);
		        strcpy(newargs, args);
		        strcat(newargs, " ");
		        strcat(newargs, query); 
		        args= newargs;
		        }
		      else 
		        args= query;
		      }
	
#if 0
		    /* 8feb95: and quote it for gopherd's paranoid checker */
		    /* no good -- need to quote EACH arg ! */
	    if (strchr(args,'\'')==0 && strchr(args,'"')== 0) {     
	      char* hp= malloc(strlen(args)+3);
	      strcpy(hp, "'"); strcat(hp,args); strcat(hp,"'"); 
	      args= hp;
	      }
#endif
	
		   EXECargs = args;
		   EXECflag = 1;
		   /*Debug( "exec+ cmd=%s, args=%s, view=%s\n",command,args,view);*/
	
		  /* printfile(sockfd, command, 0, -1, CMDisGplus(cmd), view); */
	
	    isGplus= 1; /* (strcmp(view,"text/html")!=0); //  = CMDisGplus(cmd);*/

	    /* istext= 1; /* damn problems getting this right, but need =0 for images !*/
	
		  if (view != NULL) {
		    if (GSisText(NULL, view)) istext= 1;
		    else if (strncmp(view, "text/html",9) == 0) istext= 1;
		    else if (strncmp(view, "text/plain",10) == 0) istext= 1;
		    /* else if (strncmp(view, "application/gopher-menu",23) == 0) 
	      	istext= 1; */
		    else if (strncmp(view, "application/gopher+-menu",24) == 0) 
	     		istext= 1;
		    }
			if (istext) 
				printfile(sockfd, command, 0, -1, isGplus, view);
			else
				send_binary(sockfd, command, isGplus, view);
	
		  LOGGopher(sockfd, "Executed+ %s %s", command, (args == NULL) ? " " : args);
		  }
	  break;

     case 'w':
     {
	  if (strncmp(Selstr, "waissrc:", 8) == 0) {
	       char waisfname[512];  /*** Ick this is gross ***/

	       result = GDCCanSearch(Config, CurrentPeerName, CurrentPeerIP,
				NUMgopherds);

	       if (result == SITE_NOACCESS) {
		    Abortoutput(sockfd, GDCgetBummerMsg(Config));
		    LOGGopher(sockfd, "Denied access for %s", Selstr+1);
		    break;
	       } else if (result == SITE_TOOBUSY) {
		    Abortoutput(sockfd, "Sorry, too busy now...");
		    break;
	       }

	       strcpy(waisfname, Selstr+8);
	       if (strlen(waisfname) <= 4 ||
		   strncmp(&waisfname[strlen(waisfname)-4],".src",4) )
		    strcat(waisfname, ".src");
	       SearchRemoteWAIS(sockfd, waisfname, cmd, view);
	       break;
	  }
	  else if (strncmp(Selstr, "waisdocid:", 10) == 0) {

	       result = GDCCanSearch(Config, CurrentPeerName, CurrentPeerIP,
				NUMgopherds);

	       if (result == SITE_NOACCESS) {
		    Abortoutput(sockfd, GDCgetBummerMsg(Config));
		    LOGGopher(sockfd, "Denied access for %s", Selstr+1);
		    break;
	       } else if (result == SITE_TOOBUSY) {
		    Abortoutput(sockfd, "Sorry, too busy now...");
		    break;
	       }

	       Fetchdocid(sockfd, cmd);
	       break;
	  }
     }


     default:
	  /*** Hmmm, must be an old link... Let's see if it exists ***/

	  switch (isadir(Selstr)) {
	  case -1:
	       /* no such file */
	       sprintf(logline, "'%s' does not exist", Selstr);
	       Abortoutput(sockfd, logline);
	       break;

	  case 0:
	       /* it's a file */
	       printfile(sockfd, Selstr, 0, -1, CMDisGplus(cmd), view);
	       
	       /* Log it... */
	       LOGGopher(sockfd, "retrieved file %s", Selstr);

	       break;

	  case 1:
	       /* it's a directory */
	       listdir(sockfd, Selstr, CMDisGplus(cmd), view, filter);

#ifdef LOGLOTS
	       /* Log it */
	       LOGGopher(sockfd, "retrieved directory %s", Selstr);
#endif
	       break;
	  }
     }

     /** Free data ***/
     CMDdestroy(cmd);

     return(0);
} /* doThisCommand */


int
do_commandLine(sockfd, line)
  int sockfd;
  char* line;
{
   CMDobj  *cmd;
   
   cmd = CMDnew();
   CMDfromLine( cmd, sockfd, line);
   return doThisCommand( sockfd, cmd);
}


int
do_command(sockfd)
  int sockfd;
{
     CMDobj  *cmd;
     char    *cp;

     cmd = CMDnew();

     /*** Reopen the log file ***/
     cp = GDCgetLogfile(Config);

     if (cp != NULL && *cp != '\0') {
	  if (strcasecmp(GDCgetLogfile(Config), "syslog")==0) {
	       LOGFileDesc = -2;  /** log file is syslog **/
	  } else {
	       LOGFileDesc = uopen(GDCgetLogfile(Config), 
				   O_WRONLY | O_APPEND |O_CREAT, 0644);
	  }
	  if (LOGFileDesc == -1) {
	       printf("Can't open the logfile: %s\n", GDCgetLogfile(Config));
	       gopherd_exit(-1);
	  }
     }

     if(LoadTooHigh()) {
	  Abortoutput(sockfd, "System is too busy right now. Please try again later.");
	  gopherd_exit(-1);
     }

     (void) signal(SIGALRM,read_timeout);
     (void) alarm(READTIMEOUT);

     if (setjmp(env)) {
	  LOGGopher(sockfd,"readline: Timed out!");
	  gopherd_exit(-1);
     }

     ServerSetArgv("Looking up address");

     /*** Find out who's knockin' ***/
     SOCKnetnames(sockfd, CurrentPeerName, CurrentPeerIP);
     
     ServerSetArgv("input from %s", CurrentPeerName);

     NUMgopherds = PIDnumprocs(GDCgetPiddir(Config));

#ifdef UMNDES
     if (CMDgetTicket(cmd) != NULL) {
    	  TixObj  *tix      = NULL;
	  /*** Test the ticket, and set the appropriate user ***/
	  tix=ValidTicket(sockfd, cmd);

	  if (tix == NULL)
	       return(0);
	  
	  if (Setuid_username(TIXgetUser(tix))==FALSE)
	       printf("Failed to set username to %s\n", TIXgetUser(tix));
	  Debug("We're now running as uid %d\n", geteuid());
     } else
	  /*** No ticket given, default to the defuser ***/
	  if (Gdefusername && Setuid_username(Gdefusername) == FALSE) {
	       Debug("Couldn't change uid to %s\n",Gdefusername);
	       Abortoutput(sockfd, "Can't set UID!"), gopherd_exit(-1);
	  }
#endif  /* UMNDES */

     /** Need to do this first so we can load up auxilliary gopherd.conf
         files
      **/
     CMDfromNet(cmd, sockfd);

     /** At this point there won't be any more data coming in, so shutdown
         the incoming data for the socket
      **/
     shutdown(sockfd, 0);
     
     return doThisCommand( sockfd, cmd);
}



/*
 * This function tries to find out what type of file a pathname is.
 */

void
Getfiletypes(newpath, filename, gs)
  char *newpath;
  char *filename;
  GopherObj *gs;
{
     int Zefilefd;
     static char Zebuf[256];
     char *cp;
     static char Selstr[512];

     
     switch (isadir(filename)) {
     case -1:
	  GSsetType(gs,'3');
	  return;

     case 1:
	  GSsetType(gs,A_DIRECTORY);
	  *Selstr = '1';
	  strcpy(Selstr +1, newpath);
	  GSsetPath(gs, Selstr);
	  GSsetTTL(gs, GDCgetCachetime(Config));
	  return;
     default:

	  /*** The default is a generic text file ***/
	  GSsetType(gs, A_FILE);

	  *Selstr = '0';
	  strcpy(Selstr + 1, newpath);

	  /*** Test and see if the thing exists... and is readable ***/
	  
	  if ((Zefilefd = ropen(filename, O_RDONLY)) < 0) {
	       GSsetType(gs, '3');
	       return;
	  }
	  
	  if (read(Zefilefd, Zebuf, sizeof(Zebuf)) <0) {
	       GSsetType(gs, '3');
	       return;
	  }
	  close(Zefilefd);
	  
	  /*** Check the first few bytes for sound data ***/
	  
	  cp = Zebuf;

	  if (strncmp(cp, ".snd", 4)==0) {
	       GSsetType(gs, A_SOUND);
	       *Selstr = 's';
	       strcpy(Selstr+1, newpath);
	  }

	  /*** Check and see if it's mailbox data ***/
	  
	  if (is_mail_from_line(Zebuf)==0) {
	       GSsetType(gs, A_DIRECTORY);
	       *Selstr = 'm';
	       strcpy(Selstr+1, newpath);
	       GSsetGplus(gs, FALSE);  /** Not yet.. **/
	  }
	  

	  /*** Check for uuencoding data ***/

	  if (strncmp(cp,"begin",6) == 0)  {
	       GSsetType(gs, '6');
	       *Selstr = '6';
	       strcpy(Selstr+1, newpath);
	  }
	  
	  /*** Check for GIF magic code ***/
	  
	  if (strncmp(cp, "GIF", 3) == 0) {
	       GSsetType(gs, 'I');
 	       *Selstr = '9';
 	       strcpy(Selstr + 1, newpath);
 	  }

	  GSsetPath(gs, Selstr);

     }
}

/*
 * Add a default view if none exists..
 */

void
AddDefaultView(gs, size, lang)
  GopherObj *gs;
  int size;
  char *lang;
{

     if (lang == NULL)
	  lang = GDCgetLang(Config);
     
     switch (GSgetType(gs)) {
     case A_FILE:
	  GSaddView(gs, "Text/plain", lang, size);
	  break;
     case A_DIRECTORY:
	  GSaddView(gs, "application/gopher-menu", lang, size);
	  GSaddView(gs, "application/gopher+-menu", lang, size);
	  GSaddView(gs, "text/html", lang, size);
	  break;
     case A_MACHEX:
	  GSaddView(gs, "application/mac-binhex40", lang, size);
	  break;
     case A_PCBIN:
	  GSaddView(gs, "application/octet-stream", lang, size);
	  break;
     case A_CSO:
	  GSaddView(gs, "application/qi", lang, 0);
	  break;
     case A_INDEX:
	  GSaddView(gs, "application/gopher-menu", lang, size);
	  GSaddView(gs, "application/gopher+-menu", lang, size);
	  break;
     case A_TELNET:
	  GSaddView(gs, "application/telnet", lang, 0);
	  break;
     case A_SOUND:
	  GSaddView(gs, "audio/basic", lang, size);
	  break;
     case A_UNIXBIN:
	  GSaddView(gs, "application/octet-stream", lang, size);
	  break;
     case A_GIF:
	  GSaddView(gs, "image/gif", lang, size);
	  break;	
     case A_HTML:
	  GSaddView(gs, "text/html", lang, size);
	  break;
     case A_TN3270:
	  GSaddView(gs, "application/tn3270", lang, 0);
	  break;
     case A_MIME:
	  GSaddView(gs, "multipart/mixed", lang, size);
	  break;
     case A_IMAGE:
	  GSaddView(gs, "image", lang, size);
	  break;
     }
}


#ifdef ADD_DATE_AND_TIME

void
GSaddDateNsize(gs, statbuf)
  GopherObj *gs;
  struct stat statbuf;
{
     int           fd, i;
     char         longname[256];
     char         *cdate, *ti, *fp, *stitle;
     
     switch (GSgetType(gs)) {
     case '1': /*** It's a directory ***/
     case '7': /*** It's an index ***/
     case 'f': /*** ftp link ***/
     case 'e': /*** exec link ***/
     case 'h': /*** www link ***/
     case 'w': /*** wais link ***/
     case 'm':
	  break;
     default:
     {
	  stitle = GSgetTitle(gs);
	  if (strstr( stitle, "kb]") == 0) {
	       /* Correct for multiple view items */

	       cdate= ctime( &statbuf.st_mtime); /* last mod time */
	       cdate[ 7]= 0; cdate[10]= 0; cdate[24]= 0;
	       sprintf( longname, "%s  [%s%s%s, %ukb]", stitle,
		      cdate+8,cdate+4,cdate+22, (statbuf.st_size+1023) / 1024);
	       GSsetTitle(gs,longname);
	  }
     }
	  break;
     }
}     
#else
void
GSaddDateNsize(a,b)
  GopherObj *a;
  struct stat b;
{
     ;
}

#endif /* ADD_DATE_AND_TIME */


/*
 * Add a DL description if it's there ...
 */

void
GStitlefromDL(gs, filename)
  GopherObj *gs;
  char *filename;
{
#ifdef DL
     char               dlpath[2];    /*** for DL**/
     char               *dlout;

     /* Process a "dl" description if there is one! */
     
     dlpath[0] = '.';
     dlpath[1] = '\0';
     dlout = getdesc(NULL,dlpath,filename,0);
     
     Debug("dl: %s", dlpath);
     Debug(" %s", filename);
     Debug(" %s\n", dlout);

     if (dlout != NULL) {
	  GSsetTitle(gs, dlout);
     }
#endif
     ;
}


/*
 * Load up a gopher directory from the file system 
 */

GopherDirObj *
GDfromUFS(pathname, sockfd, isGplus)
  char *pathname;
  int sockfd;
  boolean isGplus;
{
     DIR                *ZeDir;
     char               filename[256];
     static char        newpath[512];
     static GopherObj   *Gopherstow = NULL;
     static Extobj      *ext = NULL;
     GopherObj          *gs;
     struct dirent      *dp;
     GopherDirObj       *gd;
     struct stat        statbuf;
     boolean            AddItem = TRUE;
     static char        Pathp[512];
     StrArray           *Linkfiles;
     int                i, cachefd, linkdir, linkdirlimit;
 		char		* cp, * linkdirname;

     Debug("GDfromUFS:%s\r\n",pathname);
     Debug("GDfromUFS:Config=%d\r\n",Config);

     /*** Make our gopherobj ****/
     if (Gopherstow == NULL) Gopherstow = GSnew();
     gs = Gopherstow;
     if (ext == NULL) ext = EXnew();
     if ((isGplus || HTMLit) && GSgplusInited(gs) == FALSE)  GSplusnew(gs);
     gd = GDnew(32);

     if (rchdir(pathname)<0)  return(NULL);

#if 0
/* add title for html browsers */
     cp = strchr(pathname, 0);
		 do { cp--; } while (cp > pathname && *cp != '/');
     if (cp == NULL) cp= pathname;
	   GDsetTitle(gd, cp);
#endif

     if (GDCgetCaching(Config) && 
	     Cachetimedout(".cache+", GDCgetCachetime(Config), ".")==FALSE) {
	      if ((cachefd = ropen(".cache+", O_RDONLY)) >=0) {
	       GDplusfromNet(gd, cachefd, NULL);
	       close(cachefd);
	       return(gd);
	       }
       }

  Linkfiles = STAnew(10);
  gWantSort= 1; /* dgg */

	  /* dgg: added linkdir */
	linkdirname= GDCgetLinkdir(Config);
	if (linkdirname) linkdirlimit= 2; else linkdirlimit= 1;

	for (linkdir= 0; linkdir<linkdirlimit; linkdir++) {  
		 char* linkpath= NULL;
		
	   if (linkdir) {
	   	/* want gopherd.conf entry for this link.dir name ! */
	   	strcpy(newpath,pathname);
      if (newpath[strlen(newpath)-1] != '/') strcat(newpath, "/");
      strcat(newpath, linkdirname);
	   	if (rchdir(newpath)<0) break;
		  if ((ZeDir = uopendir(".")) == NULL)  break; /* exit linkdir loop */
		  linkpath= strdup(newpath);
		  pathname=linkpath;
	    }
	     
	   else if ((ZeDir = uopendir(".")) == NULL) {
      /* open "." since we just moved there - makes it work when not
	      chroot()ing and using relative paths */
		   char tmpstr[256];
		   sprintf(tmpstr, "Cannot access directory '%s'", pathname);
		   Abortoutput(sockfd, tmpstr);
		   return(NULL);
	     }

 
    for (dp = readdir(ZeDir); dp != NULL; dp = readdir(ZeDir)) {
	     AddItem = TRUE;
	     gs = Gopherstow;

#ifdef CAPFILES
	     char capfile[MAXPATHLEN];
	     FILE *SideFile;
	     strcpy(capfile,".cap/");
	     strcat(capfile, dp->d_name);
#endif
       strcpy(newpath, pathname);
	     strcpy(filename, dp->d_name);
       if (newpath[strlen(newpath)-1] != '/')  strcat(newpath, "/");
       strcat(newpath, dp->d_name);

	  if (GDCignore(Config,filename))
	     continue;
	  else if (filename[0] == '.') {
	    if (strcmp(filename, ".")==0 ||
	      strcmp(filename, "..")==0 ||
	      strncmp(filename, ".cache", 6) ==0)
	       continue;
	    else if (!isadir(filename)) {
	       /*** This is a link file, process it after other files ***/
	      String *temp = STRnew();
	      STRset(temp, filename);
	      STApush(Linkfiles, temp);
	      STRdestroy(temp);
	      continue;
	      } 
	    else 
	      continue;
	    }
	    
		if (linkdir) {
			/* screen out items already in gd, 
			   e.g., folders in main dir that replace folders in linkdir 
			*/
     long       i, len, len1, offset;
     GopherObj *gs;
     char      *cp;
     boolean   found;
	   len= strlen(filename);
     for (i=0, found= FALSE; !found && i< GDgetNumitems(gd); i++) {
	     gs = GDgetEntry(gd, i);
	     cp = GSgetPath(gs);
	     len1= strlen(cp);
	     offset= len1-len;
	     if (strcmp(filename, cp+offset) == 0)  
	       found= TRUE;
       }
			if (found) continue; /* skip this linkdir file */
			}


	  ustat(filename, &statbuf);
	  
	  gs = Gopherstow;
	  GSinit(gs);
	  GSsetHost(gs, Zehostname);
	  GSsetPort(gs, GopherPort);
	  GSsetGplus(gs, TRUE);
	  
	  Getfiletypes(newpath, filename, gs);

	  if (GSgetType(gs) == '3')
	       continue;
	  
	  GStitlefromDL(gs, filename); /** Check DL database for a good name**/

	  /* Strip any Decoder extensions from newpath before processing them
	 	   filename needs to remain as is for type checking*/
	  
	  if (EXAcasedSearch(Config->Extensions, ext, filename, EXT_DECODER)) {
	     char *foo = GSgetPath(gs);
	     newpath[strlen(newpath) - strlen(EXgetExt(ext))] = '\0';
	     foo[strlen(foo) - strlen(EXgetExt(ext))] = '\0';
	     filename[strlen(filename) - strlen(EXgetExt(ext))] = '\0';
	     }
	  
	  if (GSgetTitle(gs) == NULL)  GSsetTitle(gs, filename);
	  GSaddDateNsize(gs, statbuf);

	  /*** Add views, prefixes et al.. ***/
	  if (GDCBlockExtension(Config, filename, ext)) {
	    char *tmpstr = GSgetPath(gs);
	    int num;

	       /** Strip off the extension from the path **/
	    tmpstr[strlen(tmpstr) - strlen(EXgetExt(ext))]='\0';
	    num = GDSearch(gd, GSgetPath(gs));
	    if (num != -1) {
		    gs = GDgetEntry(gd, num);
		    AddItem = FALSE;
	      }
  
     if (HTMLit) {
	     if (AddItem && strcasecmp(EXgetBlockname(ext), "ABSTRACT") == 0) {
	       /*** Strip extension off of title && make it an info item ***/
	       filename[strlen(filename)-strlen(EXgetExt(ext))]= '\0'; 
               GSsetTitle(gs, filename); 
	       GSsetType(gs, A_INFO); 
	       /*AddItem = TRUE; */
	       }
       
   	    if (strcasecmp(EXgetBlockname(ext), "ASK") != 0)  
		      GSaddBlock(gs,EXgetBlockname(ext), fixfile(newpath));
        }
     else {
	     if (strcasecmp(EXgetBlockname(ext), "ASK") == 0)  GSsetAsk(gs, TRUE);
	     if (isGplus) GSaddBlock(gs,EXgetBlockname(ext), fixfile(newpath));
	     if (AddItem == TRUE) GSsetType(gs, '\0');
       }
	   }

	  else if (GDCViewExtension(Config, filename, &ext)) {
	    char *Prefix;
	    int  num;
	       
	    Prefix = EXgetPrefix(ext);
	    strcpy(Pathp, Prefix);
	    strcpy(Pathp+strlen(Prefix), newpath);
	       
      if (isGplus && !HTMLit) {     /* ++dgg : show all views to -client */
	       /*** Strip extension off of pathname***/
	      Pathp[strlen(Prefix)+strlen(newpath)-strlen(EXgetExt(ext))]= '\0';
	      GSsetPath(gs, Pathp);
	      GSsetType(gs, EXgetObjtype(ext));

	       /*** Strip extension off of title***/
	      filename[strlen(filename)-strlen(EXgetExt(ext))]= '\0';
	       
	       /**search for existing entry to add a view to **/
	      num = GDSearch(gd, Pathp);
	      if (num != -1) {
		      if (GSgetType(GDgetEntry(gd,num)) == '\0') {
			     GSsetHost(gs, NULL);
			     GSsetTitle(gs, filename);
			     GSmerge(GDgetEntry(gd, num), gs);
		       }
		      gs = GDgetEntry(gd, num);
		      AddItem = FALSE;
		      GSsetTitle(gs, filename);
	        } 

	       /** Oh say can we hack, by the dawns early day (:-) **/
	     if (strcasecmp(EXgetExt(ext), ".mindex")==0)  
		      GSsetGplus(gs, FALSE);

	     if (isGplus) {
		      char *lang = EXgetVLang(ext);
		      if (lang == NULL || strcmp(lang, "")==0)
			       lang = GDCgetLang(Config);
		      GSaddView(gs, EXgetView(ext), lang, statbuf.st_size);
	        }
       }     				
	else {	 	/* ++dgg : show all views to -client */
	      AddItem = TRUE;	 
	      GSsetPath(gs, Pathp);	 	
	      GSsetType(gs, EXgetObjtype(ext));
	      if (HTMLit)
	      	 GSaddView(gs, EXgetView(ext), GDCgetLang(Config), statbuf.st_size);
 	   	}	 			
	    } 
	  else if (AddItem) {
	    int num;
	    char type;
	    char *path;

	    num = GDSearch(gd, GSgetPath(gs));
	    if (num != -1) {
		    type = GSgetType(gs);
		    path = GSgetPath(gs);
		    gs = GDgetEntry(gd, num);
		    if (gs->url) { URLdestroy(gs->url); gs->url= NULL; }
		    GSsetType(gs, type);
		    GSsetPath(gs, path);
		    AddItem = FALSE;
	      } 
	    if (isGplus && GSisGplus(gs))
		    AddDefaultView(gs, statbuf.st_size, NULL);
	    }

#ifdef CAPFILES
	  if ((SideFile = rfopen(capfile, "r"))!=0) {
	       Debug("cap file name: %s\n", capfile);
	       AddItem &= Process_Side(SideFile, gs);
	       fclose (SideFile);
	       }
	  if (GSgetType(gs) == '3')	/* Some error.. */
	       continue;
	  if (GSgetType(gs) == '-')	/* Ordered to hide */
	       continue;
#endif
	  
	  if (isGplus) {
	    char tmpstr[256];
	    char timeval[16];
	    struct tm *tmthing;
	    char *cp;
	       
	    if (GSgplusInited(gs) == FALSE) GSplusnew(gs);
	       
	       /*** Add admin, abstract entries, etal ***/
	    if (!GSgetAdmin(gs)) {
		    sprintf(tmpstr, "%s <%s>", 
			    GDCgetAdmin(Config), GDCgetAdminEmail(Config));
		    GSsetAdmin(gs, tmpstr);
	      }
	       /** Set mod date entry **/
	    tmthing = localtime(&(statbuf.st_mtime));
	    strftime(timeval,sizeof(timeval), "%Y%m%d%H%M%S", tmthing);
	    sprintf(tmpstr,"%s<%s>", asctime(tmthing),timeval);
	    cp = strchr(tmpstr, '\n');
	    if (cp != NULL) *cp = ' ';
	    GSsetModDate(gs, tmpstr);
	    }
	  
	  /*** Add the entry to the directory ***/
	  if (AddItem) GDaddGS(gd, gs);
	  else AddItem = TRUE;
	  }

    for (i=0 ; i<STAgetTop(Linkfiles); i++) {
	    FileIO *fio;
	    fio = FIOopenUFS(STAgetText(Linkfiles,i), O_RDONLY, 0);
	    if (fio != NULL) {
	      GDfromLink(gd, fio, Zehostname, GopherPort, pathname, CurrentPeerName);
	      FIOclose(fio);
	      }
      }

    closedir(ZeDir);
    if (linkpath) { free(linkpath); linkpath=NULL; }
    } /* dgg: added linkdir */
     
   if (gWantSort) GDsort(gd);
   STAdestroy(Linkfiles);
   return(gd);
}



/* Misleading title - its actually loading a GD from the parent of cmd*/

GopherDirObj *
GDfromSelstr(cmd,sockfd)
  CMDobj *cmd;
  int sockfd;
{
     char *it = NULL;
     char *cp;
     GopherDirObj *gd;
     char directory[512];

     it = CMDgetFile(cmd);

     if (it == NULL)
	  return(NULL);
     else
	  strcpy(directory, it);

     cp = strrchr(directory, '/');
     if (cp != NULL)
	  *(cp+1) = '\0';
     
     if (rchdir(directory)<0) {
	  char tmpstr[512];
	  sprintf(tmpstr, "- Cannot access directory '%s'", directory);
	  Abortoutput(sockfd, tmpstr);
	  return(NULL);
     }
     
     gd = GDfromUFS(directory, sockfd, TRUE); /** Returns NULL if error **/
     
     return(gd);
}


/*
 * Send item information to client
 */
void
item_info(cmd, sockfd)
  CMDobj *cmd;
  int sockfd;
{
     GopherDirObj *gd;
     GopherObj *gs;
     int num;
     char tmpstr[256];
     char *cp;

     /* If the selstr ends in '/', strip it off. */
     cp = CMDgetSelstr(cmd);
     num = strlen(cp);
     if ( *(cp + num - 1) == '/' )
 	  *(cp + num - 1) = '\0';

 Debug("Item info: %s\n", cp);

     gd = GDfromSelstr(cmd,sockfd);

     /** For now, strip off first character and find the directory above **/
     /* Note that GDfromSelstr will return NULL (i hope) if cant find dir */

     if ((*cp == '/') || (*cp == '\0') || (*(cp+1) == '\0')) {
#if 1
		if (HTMLit) {
/***
HTTP/1.0 200 Document follows
Date: Tue, 13 Feb 1996 16:49:21 GMT
Server: NCSA/1.5
Content-type: text/html
Last-modified: Thu, 14 Sep 1995 20:40:28 GMT
Content-length: 1637

***/
		  writestring(sockfd, HTTPServerHeader);
		  sprintf(tmpstr, "Content-type: text/html%c%c",10,10);
		  writestring(sockfd, tmpstr);
		  /*
      sprintf(tmpstr, "Last-modified: %s%c%c",sdate,10,10);
		  writestring(sockfd, tmpstr);
			*/
			}
    else 
#endif
		{
	  gs = GSnew();
	  GSsetHost(gs, Zehostname);
	  GSsetPort(gs, GopherPort);
	  GSsetPath(gs, "");
	  GSsetTitle(gs, GDCgetSite(Config));
	  GSsetType(gs, '1');
	  GSsetGplus(gs, TRUE);

	  GSsendHeader(sockfd, -1);
	  writestring(sockfd, "+INFO ");
	  GStoNet(gs,sockfd, GSFORM_G0);
	  sprintf(tmpstr, "+ADMIN:\r\n Admin: %s <%s>\r\n", GDCgetAdmin(Config),
		  GDCgetAdminEmail(Config));
	  writestring(sockfd, tmpstr);
	  sprintf(tmpstr, " Site: %s\r\n", GDCgetSite(Config));
	  writestring(sockfd, tmpstr);
	  sprintf(tmpstr, " Org: %s\r\n", GDCgetOrg(Config));
	  writestring(sockfd, tmpstr);
	  sprintf(tmpstr, " Loc: %s\r\n", GDCgetLoc(Config));
	  writestring(sockfd, tmpstr);
	  sprintf(tmpstr, " Geog: %s\r\n", GDCgetGeog(Config));
	  writestring(sockfd, tmpstr);
	  sprintf(tmpstr, " Version: U of Minnesota Unix %s.%s pl%d\r\n",
		  GOPHER_MAJOR_VERSION, GOPHER_MINOR_VERSION, PATCHLEVEL);
	  writestring(sockfd, tmpstr);
	  writestring(sockfd, "+VERONICA:\r\n treewalk:");
	  if (GDCgetShouldIndex(Config) == TRUE)
	       writestring(sockfd, " yes");
	  else
	       writestring(sockfd, " no");

	  writestring(sockfd, "\r\n+VIEWS:\r\n");
	  writestring(sockfd, " application/gopher-menu: <0k>\r\n");
	  writestring(sockfd, " application/gopher+-menu: <0k>\r\n");
	  writestring(sockfd, " text/html: <0k>\r\n");
	  writestring(sockfd, " Directory/recursive: <0k>\r\n");
	  writestring(sockfd, " Directory+/recursive: <0k>\r\n");
		}
     } 
	else {

	  num = GDSearch(gd, CMDgetSelstr(cmd));
	  uchdir("/");

	  if (num < 0) {
	       GplusError(sockfd, 1, "Cannot find item information for that item", NULL);
	       return;
	  }
	  else {
#if 1
		if (HTMLit) {
		  writestring(sockfd, HTTPServerHeader);

		  gs = GDgetEntry(gd, num);
      GShttpHeadtoNet(gs, sockfd, NULL);
			}
		else
#endif
			{
	       gs = GDgetEntry(gd, num);
	       GSsendHeader(sockfd, -1);
	       GSplustoNet(gs, sockfd, NULL);
			}
	  }

     }
     if (gd)
	  GDdestroy(gd);

     writestring(sockfd, EOTstring);
}
     

/*
** This function lists out what is in a particular directory.
** it also outputs the contents of link files.
**
** It also checks for the existance of a .cache file if caching is
** turned on...
**
** Ack is this ugly.
*/

void
listdir(sockfd, pathname, isgplus, view, filter)
  int sockfd;
  char *pathname;
  boolean isgplus;
  char *view;
  char *filter;
{
     GopherDirObj *gd = NULL;
     boolean      attrlist = FALSE;
     boolean      Recurse  = FALSE;
     char         *filtereddata[16], **filtered=filtereddata;
     int          i=0;
     StrArray     *RecurseDirs;
     String       *stapath;
     String       *pushstring = STRnew();
     int          result;


     result = GDCCanBrowse(Config, CurrentPeerName, CurrentPeerIP,
			   NUMgopherds);
     
     if (result == SITE_NOACCESS) {
	  Abortoutput(sockfd,  GDCgetBummerMsg(Config));
	  return;
     } else if (result == SITE_TOOBUSY) {
	  Abortoutput(sockfd, "Sorry, too busy right now..");
	  return;
     }


     if (uchdir("/"))
	  perror("SOL dude");

     if (filter != NULL) {
	  while (*filter != '\0') {
	       if (*filter=='+') {
		    *filter = '\0';
		    filtered[i] = filter+1;
		    filter++; i++;
	       }
	       filter++;
	  }
	  filtered[i] = NULL;
     } else
	  filtered = NULL;


     if (view != NULL) {
	  if (strncmp(view, "application/gopher+-menu",24) == 0)
	       attrlist = TRUE;
	  else if (strncmp(view, "text/html", 9) == 0) {
	       attrlist = TRUE;
	       if (!HTMLit) HTMLit = 1;
	  }
	  else if (strncmp(view, "Directory+/recursive", 20)==0)
	       Recurse = TRUE;
	  else if (strncmp(view, "Directory/recursive", 19)==0)
	       Recurse = TRUE;
     }
     if (Recurse)
	  RecurseDirs = STAnew(32);

     if (rchdir(pathname)<0) {
	  char tmpstr[512];

	  if (errno == EACCES)
#ifdef UMNDES
	       PleaseAuthenticate(sockfd);
#endif
	  ;
	  sprintf(tmpstr, "- Cannot access directory '%s'", pathname);
	  Abortoutput(sockfd, tmpstr);
	  return;
     }
	  IsHTML= HTMLit;

     if (isgplus)
	  GSsendHeader(sockfd, -1);


     do {
	  Debug("Sending %s\n", pathname);

	  if (Recurse) {
	       rchdir("/");
	       rchdir(pathname);
	  }

	  
	  if (!attrlist && GDCgetCaching(Config) && !HTMLit &&
	     (Cachetimedout(".cache", GDCgetCachetime(Config), ".") ==FALSE)) {
	       /*** Old style cache  ***/
	       send_binary(sockfd, ".cache", FALSE, NULL);

	  } else if (GDCgetCaching(Config) && !HTMLit &&
		     Cachetimedout(".cache+", GDCgetCachetime(Config)
				   , ".")==FALSE) {
	       /*** Gopher+ cache. ***/
	       
	       if (strcmp(view, "application/gopher+-menu")==0)
		    send_binary(sockfd, ".cache+", FALSE, NULL);
	       else if (strcmp(view, "application/gopher-menu")==0)
		    send_binary(sockfd, ".cache", FALSE, NULL);
	       
	  } else {
	       /** If we didn't cache then we have to 
		 load up the directory **/
	       gd = GDfromUFS(pathname, sockfd, attrlist);
	       
	       if (gd == NULL) {
		    /** Should generate an error message here **/
		    break;
	       }

	       rchdir("/");
	       
	       if (HTMLit) {
#if 0
HTTP/1.0 200 OK
Date: Monday, 24-Apr-95 01:21:20 GMT
Server: NCSA/1.3
MIME-version: 1.0
Content-type: text/html

<HEAD><TITLE>Index of /</TITLE></HEAD><BODY>
<TITLE>IUBio Archive for Biology data and software</TITLE>
</HEADER>
<BODY>
...
</BODY>
----------------------
GET /srs/arrow_icon.gif HTTP/1.0

HTTP/1.0 200 OK
Date: Saturday, 13-May-95 01:25:24 GMT
Server: NCSA/1.3
MIME-version: 1.0
Content-type: image/gif
Last-modified: Friday, 03-Feb-95 10:46:40 GMT
Content-length: 123

GIF89a... data
#endif
		    STATSTR   statbuf;
		    char      html_path[1024];
				netline= hnewline; /* no \r */
				EOTstring= hEOTstring;
	      IsHTML= HTMLit;
				
       if (HTMLit > 1 && view) {
		      /* fix for En_US appendage on view ! */
		      char* sp; if ((sp=strchr(view,' '))!=NULL) *sp= 0;
	   	      writestring(sockfd, HTTPServerHeader);
		      sprintf(html_path, "Content-type: %s%c%c",view,10,10);
		      writestring(sockfd, html_path);
	 /* HTMLit = 1;*/ /* so we don't write another header !?*/
         }

		    writestring(sockfd, "<HTML>\n<HEAD>\n");

		    writestring(sockfd, "<LINK rev=made href=\"mailto:");
		    writestring(sockfd, GDCgetAdminEmail(Config));
		    writestring(sockfd, "\">\n");

#if 0	    
/* dgg -- GDsetTitle() is never called... this wipes out title set by .about.. */	
		    if (GDgetTitle(gd) != NULL) {
			 writestring(sockfd, "<TITLE>");
			 writestring(sockfd, GDgetTitle(gd));
			 writestring(sockfd, "</TITLE>");
		    }
#endif
		  
		    writestring(sockfd, "</HEAD>\n<BODY>\n");

                        /* dgg addition for .about.html -only !*/
                    strcpy    (html_path, pathname);
                    strcat    (html_path, ".only.html");
		    if (rstat(html_path, &statbuf) != 0) {
              		strcpy(html_path, pathname);
       			if (html_path[strlen(html_path)-1] != '/')  strcat(html_path, "/");
              		strcat(html_path, ".only.html");
		        }
                    if (rstat(html_path, &statbuf) == 0) {
                        send_binary(sockfd, html_path, FALSE, NULL);
		        writestring(sockfd, "</BODY>\n</HTML>\n");
                        return;
			}

		    strcpy(html_path, pathname);
		    strcat(html_path, ".about.html");
		    if (rstat(html_path, &statbuf) != 0) {
                       strcpy(html_path, pathname);
       			if (html_path[strlen(html_path)-1] != '/')  strcat(html_path, "/");
                       strcat(html_path, ".about.html");
			}
		    if (rstat(html_path, &statbuf) == 0) 
			 send_binary(sockfd, html_path, FALSE, NULL);
		    else if (strcmp(pathname, "/") == 0) {
			 writestring(sockfd, "<H1>");
			 writestring(sockfd, GDCgetSite(Config));
			 writestring(sockfd, "</H1>\n<H2>");
			 writestring(sockfd, GDCgetOrg(Config));
			 writestring(sockfd, "</H2>\n");
		    }
	       
		    GDtoNet(gd, sockfd, GSFORM_HTML);
		    writestring(sockfd, "</BODY>\n</HTML>\n");
	       }
	       else if (attrlist)
		    GDplustoNet(gd, sockfd,filtered);
	       else
		    GDtoNet(gd, sockfd, GSFORM_G0);

	  }
	  /*
	   * Write out the cache... After we send out the data to the net.
	   */
	  if (GDCgetCaching(Config) 
	    && GDCgetCaching(Config) != 3 /* dgg, flag for no cache write... */
	    && gd != NULL) {
	       int cachefd;
	       char cachefile[MAXPATHLEN];
	       
	       strcpy(cachefile, pathname);
       		if (cachefile[strlen(cachefile)-1] != '/')  strcat(cachefile, "/");
	       strcat(cachefile, ".cache");
	       
	       cachefd = ropen(cachefile, O_WRONLY|O_CREAT|O_TRUNC, 0644);
	       
	       if (cachefd >= 0) {
		    Debug("Caching directory... into %s\n",cachefile);
		    GDtoNet(gd, cachefd, GSFORM_G0);
		    close(cachefd);
	       }
	       
	       if (attrlist) {
		    strcat(cachefile, "+");
			 
		    cachefd = ropen(cachefile, O_WRONLY|O_CREAT|O_TRUNC,0644);
		    
		    if (cachefd >= 0) {
			 GDplustoNet(gd, cachefd,filtered);
			 close(cachefd);
		    }
	       }
	  }
	  
	  if (Recurse) {
	       GopherObj *gs;
	       /** Push entries on the stack **/
	       for (i=0; i< GDgetNumitems(gd); i++) {
		    STATSTR stbuf;
		    char    *cp;

		    gs = GDgetEntry(gd, i);

		    if ((GSgetType(gs) == A_DIRECTORY) &&
			(strcmp(GSgetHost(gs), Zehostname) == 0)) {
			 STRset(pushstring,  GSgetPath(gs));

			 rchdir("/");

			 cp = STRget(pushstring);
			 if (rstat(cp+1, &stbuf) == 0)
			      STApush(RecurseDirs, pushstring);
		    }
	       }

	       do {
		    stapath = STApop(RecurseDirs);
		    if (stapath == NULL) {
			 Recurse = FALSE;  /** Done **/
			 break;
		    }
		    pathname = STRget(stapath);
		    
		    if (*pathname == 'm')
			 process_mailfile(sockfd, pathname+1);
	       } while (*pathname == 'm');

	       pathname++;

	       if (gd != NULL) {
		    GDdestroy(gd);
		    gd = NULL;
	       }
	  }
     } while (Recurse);

     writestring(sockfd, EOTstring);

}


/*
 * This processes a file containing any subset of
 * Type, Name, Path, Port or Host, and returns pointers to the
 * overriding data that it finds.
 *
 * The caller may choose to initialise the pointers - so we don't
 * touch them unless we find an over-ride.
 */

int
Process_Side(sidefile, Gopherp)
  FILE *sidefile;
  GopherObj *Gopherp;
{
     char inputline[MAXLINE];
     char *cp;
     int  retval = TRUE;

     inputline[0] = '\0';

     for (;;) {
	  for (;;) {
	       cp = fgets(inputline, 1024, sidefile);
	       if (inputline[0] != '#' || cp == NULL)
		    break;
	  }
	  
	  /*** Test for EOF ***/
	  if (cp==NULL)
	       break;
	  
	  ZapCRLF(inputline);  /* should zap tabs as well! */

	  /*** Test for the various field values. **/
	  
	  if (strncmp(inputline, "Type=", 5)==0) {
	       GSsetType(Gopherp, inputline[5]);
	       if (inputline[5] == '7') {
		    /*** Might as well set the path too... ***/
		    cp = GSgetPath(Gopherp);
		    *cp = '7';
	       } else if (inputline[5] == '9') {
		    /*** Might as well set the path too... ***/
		    cp = GSgetPath(Gopherp);
		    *cp = '9';
	       } else if (inputline[5] == '-') {
		    retval = FALSE;
	       }

	  }

	  else if (strncmp(inputline, "Name=", 5)==0) {
	       GSsetTitle(Gopherp, inputline+5);
	  }

	  else if (strncmp(inputline, "Host=", 5)==0) {
	       GSsetHost(Gopherp, inputline+5);
	  }

	  else if (strncmp(inputline, "Port=", 5)==0) {
	       GSsetPort(Gopherp, atoi(inputline+5));
	  }

	  else if (strncmp(inputline, "Path=", 5)==0) {
	       GSsetPath(Gopherp, inputline+5);
	  }

	  else if (strncmp(inputline, "Numb=", 5)==0) {
	       GSsetNum(Gopherp, atoi(inputline+5));
	  }

	  else if (strncmp(inputline, "Name=", 5)==0) {
	       GSsetTitle(Gopherp, inputline+5);
	  }

	  else if (strncmp(inputline, "Abstract=", 9)==0) {
	       GSsetAbstract(Gopherp, inputline+9);
	  }

	  else if (strncmp(inputline, "Admin=", 9)==0) {
	       GSsetAdmin(Gopherp, inputline+6);
	  }

     }

     return(retval);
}



/* dgg++    special test & action for netdocs (docs w/ golink data in front */

#define DocLinkExt  "-dlink"
#define DocLinkExtLen  6

void CheckNSendDocLinks(sockfd, pathname, Gplus)
  int    sockfd;
  char * pathname;
  boolean Gplus;
{
  FILE    *infile;
  char    outputline[512];
  char  * cp;
  
  cp= pathname + strlen(pathname) - DocLinkExtLen;
  if (strncmp( cp, DocLinkExt, DocLinkExtLen) == 0) {
    infile = rfopen(pathname, "r");
    *cp= 0;  /* chop extension off pathname */
    if (infile==NULL) return;
    if (Gplus) GSsendHeader(sockfd, -1);
    writestring(sockfd, "+MENU:\r\n");
    while (fgets(outputline, sizeof(outputline), infile)!=NULL)  {
       ZapCRLF(outputline);
       writestring(sockfd, " ");
       writestring(sockfd, outputline);
       writestring(sockfd, "\r\n");
       }
    writestring(sockfd, "+DATA:");  /* no \r\n -- leave for GSsendHeader */
    fclose(infile);
    }
}





void
putHTTPhead(sockfd, itsView, itsSize)
  int     sockfd;
  char    *itsView;
  int     itsSize;
{
  char outline[MAXLINE];
  
  if (itsView) {
    /* fix for En_US appendage on view ! */
    char* sp; if ((sp=strchr(itsView,' '))!=NULL) *sp= 0;
    writestring(sockfd, HTTPServerHeader);
    if (!itsSize) {
      sprintf(outline, "Content-type: %s\n\n",itsView);
      writestring(sockfd, outline);
      }
    else {
      sprintf(outline, "Content-type: %s\n",itsView);
      writestring(sockfd, outline);
      sprintf(outline, "Content-length: %d\n\n",itsSize);
      writestring(sockfd, outline);
      }
    }
}

/*
** This function opens the specified file, starts a zcat if needed,
** and barfs the file across the socket.
**
** It now also checks and sees if access is allowed
**
**  This also used the global variable ASKfile
**
*/

void
printfile(sockfd, pathname, startbyte, endbyte, Gplus, itsView)
  int     sockfd;
  char    *pathname;
  int     startbyte, endbyte;
  boolean Gplus;
  char    *itsView; /* dgg */
{
     FILE        *ZeFile;
     char         inputline[MAXPATHLEN];
     FILE        *pp;
     static char *writebuf = NULL;
     static char *bufptr   = NULL;
     int          len;
     int          result, iline;
     boolean      isAskfile= FALSE;

     /*** Check and see if the peer has permissions to read files ***/
     
     result = GDCCanRead(Config, CurrentPeerName, CurrentPeerIP, NUMgopherds);

     if (result == SITE_NOACCESS) {
	  Abortoutput(sockfd, GDCgetBummerMsg(Config));
	  LOGGopher(sockfd,"Denied access for %s", pathname);
	  return;
     } else if (result == SITE_TOOBUSY) {
	  Abortoutput(sockfd, "Sorry, too busy right now. Try again in a few minutes");
	  return;
     }


     /* dgg++  patch to block ASK calls from bad clients */
     if (FileExists(pathname,".ask")) {
	  if (!Gplus || !ASKfile) {
	       char errmsg[256];
	       if (!ASKfile)
		    sprintf(errmsg," Missing input data to ASK form\t\t\t\r\n");
	       else
		    sprintf(errmsg," This ASK form needs a gopher+ client\t\t\t\r\n");
	       Abortoutput(sockfd, errmsg);
	       return;
          }
     isAskfile= TRUE;
     }
     else 
     	CheckNSendDocLinks(sockfd, pathname, Gplus); /* dgg addition */

     if ( (ZeFile = rfopen(pathname, "r")) == NULL) {
	  /*
	   * The specified file does not exist
	   */
	  char notexistline[256];
	  sprintf(notexistline, "'%s' does not exist!!", pathname);
	  Abortoutput(sockfd, notexistline);

	  return;
     }

     if (writebuf == NULL) {
	  writebuf = malloc(4096 * sizeof(char));
	  bufptr   = writebuf;
     }

     if (startbyte != 0)
	  fseek(ZeFile, startbyte, 0);
     
/* dgg add for ASK scripts -- pass some cmdline parameters to the script */
/* causing problems?? */
     if ((isAskfile || EXECargs) && itsView ) {
	  if (EXECflag != 3) {
	    strcpy(inputline, " -v ");
	    strcat(inputline, itsView);
    	    }
     else  *inputline= 0;
	 if (EXECargs) { 
					strncat(inputline, " ",sizeof(inputline)); 
					strncat(inputline,EXECargs,sizeof(inputline)); 
					}
        EXECargs = inputline;
	}

    if ((pp = specialfile(sockfd, ZeFile, pathname))!=NULL) {	/* Ick uses global ASKfile*/
	  fclose(ZeFile);
	  ZeFile = pp;
     }

     if (Gplus && !HTMLit)
	 GSsendHeader(sockfd, -1);
     else if (HTMLit > 1 && itsView) {
     	}
     else if (HTMLit && strcmp(itsView,"text/plain")==0) {
	/* dgg dec95 fix goph-text ? */
	 writestring(sockfd, "<pre>\n");
	 }

     iline=0;
     while (fgets(inputline, sizeof(inputline), ZeFile) != NULL) {
     
     	  if (!iline && HTMLit>1) {
     	    if (strncmp(inputline, "Location: ", 10)==0) {
     	  	/* dgg - add for http location: cmd */
     	  	char buf[512];
     	  	sprintf(buf,"GET %s\n", inputline+10);
     		(void) do_commandLine( sockfd, buf);
     		return;
     	  	}
     	    else   
     	      putHTTPhead( sockfd, itsView, 0);
     	    }
	  ZapCRLF(inputline); 
	  iline++;
			
	  /** Period on a line by itself, double it.. **/
	  if (*inputline == '.' && inputline[1] == '\0' && !EXECflag) {
	       inputline[1] = '.';
	       inputline[2] = '\0';
	  }

	  strcat(inputline, netline);
	  len = strlen(inputline);

	  if (((bufptr-writebuf) + len+1) > 4096) {
	       /** Write out the buffer if it's too big to fit.. **/
	       if (writestring(sockfd, writebuf))
		    LOGGopher(sockfd, "Client went away"), gopherd_exit(-1);
	       bufptr=writebuf;
	  }

	  strcpy(bufptr, inputline);
	  bufptr += len;
	  *bufptr = '\0';
	  
	  if (endbyte >0) {
	       if (ftell(ZeFile) >= endbyte)
		    break;
	  }
     }

     if (bufptr != writebuf)
	  writestring(sockfd, writebuf);

#ifdef SLOWOUTPUT
/* ?? need a sleep(1) here for DEC ?? */
		 sleep(1);
#endif

     Specialclose(ZeFile);

     if (writestring(sockfd, EOTstring)<0)
	  LOGGopher(sockfd, "Client went away"), gopherd_exit(-1);
}


#define BUFSIZE 8192  /* No, user process can't affect Kernel-IP
			 decission on what the actual output MTU is.
			 System call overhead may well be too great
			 to care for this.  If the protocol had been
			 on top of the UDP, things would be
			 different..  [mea@gopher.funet.fi] */

void
send_binary(sockfd, filename, isGplus, itsView)
  int sockfd;
  char *filename;
  boolean isGplus;
  char   *itsView; /* dgg */
{

     FILE           *sndfile,*pp;
     unsigned char  in[BUFSIZE];
     register int   j;
     int            gotbytes, size;
     struct stat    buf;
     int            result, iline;
     boolean isAskfile= FALSE;

     /** Don't check decoder/extension if .cache **/
     if (strncmp(filename, ".cache",6)!=0) {

	  result = GDCCanRead(Config, CurrentPeerName, CurrentPeerIP, 
			      NUMgopherds);
	  if (result == SITE_NOACCESS) {
	       Abortoutput(sockfd, GDCgetBummerMsg(Config));
	       return;
	  } else if (result == SITE_TOOBUSY) {
	       Abortoutput(sockfd, "Too busy right now");
	       return;
	  }
	  
 /* ++dgg  patch to block ASK calls from bad clients */
     if (FileExists(filename,".ask")) {
        if (!isGplus || !ASKfile) {
           char errmsg[256];
          if (!ASKfile)
            sprintf(errmsg," Missing input data to ASK form\t\t\t\r\n");
          else
            sprintf(errmsg," This ASK form needs a gopher+ client\t\t\t\r\n");
          Abortoutput(sockfd, errmsg);
          return;
          }
        isAskfile= TRUE;
        }
     else 
     	CheckNSendDocLinks(sockfd, filename, isGplus); /* dgg addition */
 
	  if (strcmp(filename, "-") == 0) {
	       /*** Do some live digitization!! **/
	       sndfile = popen("record -", "r");
	  }
	  else
	       sndfile = rfopen(filename, "r");
	  
	  if (!sndfile) {
	       /*
		* The specified file does not exist
		*/
	       char notexistline[256];
	       sprintf(notexistline, "'%s' does not exist!!", filename);
	       Abortoutput(sockfd, notexistline);
	       
	       return;
	  }

/* dgg add for ASK scripts -- pass some cmdline parameters to the script */
/* causing problems?? */
     if ((isAskfile || EXECargs) && itsView ) {
          if (EXECflag != 3) {
            strcpy(in, " -v ");
            strcat(in, itsView);
            }
         else *in= 0;
			  if (EXECargs) {
				  strncat(in," ",sizeof(in)); 
					strncat(in, EXECargs,sizeof(in));
					}
        EXECargs = (char*)in;
	}

	  if ((pp = specialfile(sockfd, sndfile, filename)) != NULL) {
	       fclose(sndfile);
	       sndfile = pp;
	  }
     } else
	  sndfile = rfopen(filename, "r");


     if ((isGplus && !HTMLit) && strcmp(filename, "-") == 0) 
	  GSsendHeader(sockfd, -2);
     else if (isGplus && !HTMLit) {
	  rstat(filename, &buf);
	  size = buf.st_size;
	  GSsendHeader(sockfd, size);
         }
#if 1
     else if (HTMLit > 1 && itsView) {
      	rstat(filename, &buf);
	size = buf.st_size;
        }
#endif



     iline= 0;
     while(1) {
	 gotbytes = fread(in, 1, BUFSIZE, sndfile);
	 if (gotbytes == 0)  break;       /*** end of file or error... ***/
     	 if (!iline && HTMLit>1) {
      	    if (strncmp(in, "Location: ", 10)==0) {
     	  	/* dgg - add for http location: cmd */
     	  	char buf[512];
     	  	sprintf(buf,"GET %s\n", in+10);
     		(void) do_commandLine( sockfd, buf);
     		return;
     	  	}
     	    else   
     	      putHTTPhead( sockfd, itsView, size);
     	    }
     	 iline++;
         j = writen(sockfd, in, gotbytes);
	 if (j == 0) break;       /*** yep another error condition ***/
	 Debug("send_binary: sent %d bytes\n",j);
       }

#ifdef SLOWOUTPUT
/* ?? need a sleep(1) here for DEC ?? */
		 sleep(1);
#endif

     Specialclose(sndfile);
}

