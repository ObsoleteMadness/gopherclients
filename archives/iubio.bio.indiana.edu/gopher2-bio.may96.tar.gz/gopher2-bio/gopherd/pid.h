/********************************************************************
 * lindner
 * 3.2
 * 1994/04/08 21:13:03
 * /home/mudhoney/GopherSrc/CVS/gopher+/gopherd/pid.h,v
 * Exp
 *
 * Paul Lindner, University of Minnesota CIS.
 *
 * Copyright 1991,92,93,94 by the Regents of the University of Minnesota
 * see the file "Copyright" in the distribution for conditions of use.
 *********************************************************************
 * MODULE: pid.h
 * Abstraction of all PID routines
 *********************************************************************
 * Revision History:
 * pid.h,v
 * Revision 3.2  1994/04/08  21:13:03  lindner
 * Fix for ansi C compilers
 *
 * Revision 3.1  1994/03/17  04:33:38  lindner
 * New pid routines
 *
 *
 *
 *********************************************************************/

/*
 * This is the interface for all the PID routines
 */

void PIDwrite( /* char* char* */);
int  PIDnumprocs( /* ... */);
void PIDdone(/* ... */);

#if defined(__STDC__) || defined(__stdc__)
 void PIDwritef(char *piddir, const char *fmt, ...);
#else
 void PIDwritef();
#endif
