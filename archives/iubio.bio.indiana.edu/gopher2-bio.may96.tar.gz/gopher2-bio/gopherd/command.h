/********************************************************************
 * lindner
 * 3.6
 * 1993/10/04 06:49:21
 * /home/mudhoney/GopherSrc/CVS/gopher+/gopherd/command.h,v
 * Exp
 *
 * Paul Lindner, University of Minnesota CIS.
 *
 * Copyright 1991, 1992, 1993 by the Regents of the University of Minnesota
 * see the file "Copyright" in the distribution for conditions of use.
 *********************************************************************
 * MODULE: command.h
 * Definitions and prototypes for CMD object.
 *********************************************************************/


#ifndef COMMAND_H
#define COMMAND_H

#include "STRstring.h"
#include "STAarray.h"
#include "tix.h"
#include "boolean.h"


struct command_struct {
     String  *datafromnet;

     boolean isGplus;

     char    *selstr;
     char    *command;
     char    *search;
     
     String  *view;
     String  *secureuser;
     String  *ticket;

     StrArray *asklines;
};

typedef struct command_struct CMDobj;


#define CMDgetSelstr(a)    ((a)->selstr)
#define CMDsetSelstr(a,b)  ((a)->selstr=(b))
#define CMDgetCommand(a)   ((a)->command)
#define CMDsetCommand(a,b) ((a)->command=(b))

#define CMDgetSearch(a)    ((a)->search)
#define CMDsetSearch(a,b)  ((a)->search=(b))

#define CMDgetData(a)      (STRget((a)->datafromnet))
#define CMDsetData(a,b)    (STRset((a)->datafromnet, b))

void    CMDpushAskline();
#define CMDgetAskline(a,b)  (STAgetText((a)->asklines,b))
#define CMDisAskitem(a)     (STAgetTop((a)->asklines)!= 0)
#define CMDnumAsklines(a)   (STAgetTop((a)->asklines))

#define CMDisGplus(a)      ((a)->isGplus)
#define CMDsetGplus(a,b)   ((a)->isGplus=b)

#define CMDgetView(a)      (STRget((a)->view))
#define CMDsetView(a,b)    (STRset((a)->view,b))

#define CMDgetUser(a)      (STRget((a)->secureuser))
#define CMDsetUser(a,b)    (STRset((a)->secureuser,(b)))

#define CMDgetTicket(a)    (STRget((a)->ticket))
#define CMDsetTicket(a,b)  (STRset((a)->ticket,(b)))

CMDobj *CMDnew();
void    CMDdestroy();
void    CMDfromNet();
void		CMDfromLine();
void    CMDgetXtra();
char   *CMDticketfromLine();
char   *CMDgetFile();
#endif
