/********************************************************************
 * lindner
 * 3.1.1.1
 * 1993/02/11 18:02:51
 * /home/mudhoney/GopherSrc/CVS/gopher+/gopherd/globals.c,v
 * $Status: $
 *
 * Paul Lindner, University of Minnesota CIS.
 *
 * Copyright 1991, 1992 by the Regents of the University of Minnesota
 * see the file "Copyright" in the distribution for conditions of use.
 *********************************************************************
 * MODULE: globals.c
 * declarations of globals defined in globals.h
 *********************************************************************
 * Revision History:
 * globals.c,v
 * Revision 3.1.1.1  1993/02/11  18:02:51  lindner
 * Gopher+1.2beta release
 *
 * Revision 1.1  1992/12/10  23:13:27  lindner
 * gopher 1.1 release
 *
 *
 *********************************************************************/


#define EXTERN
#include "gopherd.h"
