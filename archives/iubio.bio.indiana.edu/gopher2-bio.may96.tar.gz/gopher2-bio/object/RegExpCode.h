
/* dgg hack -- system /usr/include/regexp.h HAS DAMN SOURCE CODE IN IT
	so the compile/step/advance routines are compiled into
	each object including it, and then are multiply defined
	over different libraries, causing linker to choke */

#ifndef _REGEXP_H
#define	_REGEXP_H


#include <string.h>

#ifdef	__cplusplus
extern "C" {
#endif

#define	CBRA	2
#define	CCHR	4
#define	CDOT	8
#define	CCL	12
#define	CXCL	16
#define	CDOL	20
#define	CCEOF	22
#define	CKET	24
#define	CBACK	36
#define	NCCL	40

#define	STAR	01
#define	RNGE	03

#define	NBRA	9

#define	PLACE(c)	ep[c >> 3] |= bittab[c & 07]
#define	ISTHERE(c)	(ep[c >> 3] & bittab[c & 07])
#define	ecmp(s1, s2, n)	(!strncmp (s1, s2, n))

static char	*braslist[NBRA];
static char	*braelist[NBRA];
int	sed, nbra;
char	*loc1, *loc2, *locs;
static int	nodelim;

int	circf;
static int	low;
static int	size;

static unsigned char	bittab[] = { 1, 2, 4, 8, 16, 32, 64, 128 };


#ifdef	__STDC__

int REXadvance(register char *lp, register char *ep);
static void REXgetrnge(register char *str);
char * REXcompile(char *instring, register char *ep, char *endbuf, int seof);
int REXstep(register char *p1, register char *p2);

#else

int REXadvance();
static void REXgetrnge();
char * REXcompile(instring, ep, endbuf, seof);
int REXstep(p1, p2);
#endif

 
#ifdef	__cplusplus
}
#endif

#endif	/* _REGEXP_H */
