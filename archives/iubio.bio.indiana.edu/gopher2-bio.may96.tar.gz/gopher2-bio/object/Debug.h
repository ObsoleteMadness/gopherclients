#ifndef DEBUG_H
#define DEBUG_H

#include "boolean.h"

extern boolean DEBUG;

#ifdef DEBUGGING
#  include <stdio.h>
#if 1
/* dgg - damn bug in solaris2 ! - printf("%s",NULL) kills app ! */
#  define Debug(str,val) if (DEBUG) { if (val || !strstr(str,"%s"))  fprintf(stderr,str, val); else fprintf(stderr,str, "(null)" ); }
#else
#  define Debug(str,val) if (DEBUG) { fprintf(stderr,str,val); }
#endif
#  define DebugGSplusPrint(gop,str) if (DEBUG) { GSplusPrint(gop,str); }

#else 

#  define Debug(str,val)
#  define DebugGSplusPrint(gop,str)

#endif

#endif /* DEBUG_H */
