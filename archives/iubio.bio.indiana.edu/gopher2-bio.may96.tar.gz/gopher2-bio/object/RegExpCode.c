

/* dgg hack -- system /usr/include/regexp.h HAS DAMN CODE IN IT
	so the compile/step/advance routines are compiled into
	each object including it, and thus are multiply defined
	over different libraries */

/*#include "RegExpCode.h"*/

#     define INIT   register char *sp = instring;
#     define GETC() (*sp++)
#     define PEEKC()     (*sp)
#     define UNGETC(c)   (--sp)
#     define RETURN(c)   return(NULL);
#     define ERROR(c)    return("error")

#ifndef NULL 
#	define NULL 0
#endif

#include <regexp.h>

char *
#ifdef	__STDC__
REXcompile(char *instring, register char *ep, char *endbuf, int seof)
#else
REXcompile(instring, ep, endbuf, seof)
register char *ep;
char *instring, *endbuf;
#endif
{

	return compile( instring,  ep,  endbuf,  seof);

}

#ifdef	__STDC__
int REXstep(register char *p1, register char *p2)
#else
int REXstep(p1, p2)
register char *p1, *p2;
#endif
{
	return step( p1, p2);
}

int
#ifdef	__STDC__
REXadvance(register char *lp, register char *ep)
#else
REXadvance(lp, ep)
register char *lp, *ep;
#endif
{
	return advance(lp, ep);
}

static void
#ifdef	__STDC__
REXgetrnge(register char *str)
#else
REXgetrnge(str)
register char *str;
#endif
{
#ifndef _OSF_SOURCE
	getrnge(str);
#endif
}

