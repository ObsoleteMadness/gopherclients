#!/bin/sh
#
# This is used on a remote ftp server; it retrieves a "ls -lR" listing and
# turns it into a travel file.
#
# Remember to create an empty ftp.gtimes.gz for the first run.

PATH=/usr/local/bin:/bin:/usr/bin:/usr/ucb:/usr/new/mh:/usr/spool/archive/bin
export PATH

cd /usr/spool/gopher/travel


# Retrieve the "ls -lR" listing of the ftp archive.

ftpcat a.ftp.server.address:/pub/FULLINDEX.Z > ftp.ls-lR.Z || exit 1

# Use the following if the archive doesn't keep its own listings.
#
# (echo user anonymous -travel@my.mail.address
#  echo 'ls -lR "| gzip -c > ftp.ls-lR.gz"') | ftp -n a.ftp.server.address


# Transform the file listing into a travel file.
# Keeping everything compressed trades time for disk space.
# Note the "echo pub:" to correct things for the first directory; you may
# have to fiddle with this.

(echo pub: ; zcat ftp.ls-lR.Z) | \
    lstravel -k ftp.kill -f a.ftp.server.address my.gopher.server 70 | \
    gzip > ftp.travel.gz


# Merge the new travel with the old memories.

zcat ftp.gtimes.gz ftp.travel.gz | gtimes > ftp.new &&
  (mv ftp.gtimes.gz ftp.bak.gz; mv ftp.new ftp.gtimes; gzip ftp.gtimes)
