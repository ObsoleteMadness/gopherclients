#!/bin/sh
# This is to be used on the filesystem of an ftp area.  It "travels" through
# the filesystem directly.
#
# Remember to create an empty fs.gtimes file for the first run.
#
PATH=/usr/local/bin:/bin:/usr/bin:/usr/ucb:/usr/new/mh:/usr/spool/archive/bin
export PATH
T=/usr/spool/gopher/travel


# Travel through the filesystem and collect a travel file.

rm $T/fs.travel.gz
cd /my/ftp/area/pub
ftravel -k $T/fs.kill -d 1 myserver.address 70 \
     | gzip > $T/fs.travel.gz


# Generate the pretty listing.

cd $T
zcat fs.travel.gz | gpretty -d 2 -M -h gopher.fct.unl.pt > fs.pretty


# Update the old memories.

zcat fs.gtimes.gz fs.travel.gz | gtimes -x > fs.new &&
  (mv fs.gtimes.gz fs.bak.gz; mv fs.new fs.gtimes; gzip fs.gtimes)
