#!/bin/sh
#
#  If called with -u, updates the travel file;
#  if called with -x, keeps old entries around (otherwise it will delete
#  them with every connectivity problem).
#
#  Normal usage is: world.sh -u -x
#
#  Remember to create an empty world.gtimes.gz file for the first run.
#
#  Also, be nice to the gopher entry points; travelling them once a week is
#  enough, and you can share the resulting travel files with your friends...
#
PATH=/usr/local/bin:/bin:/usr/bin:/usr/ucb:/usr/new/mh:/usr/spool/archive/bin
export PATH

# Parse the options -u and -x

for i in $*; do
  if [ "$i" = -u ]
     then OPT_u=-u;
     else if [ "$i" = -x ]
             then OPT_x=-x;
             else echo $0 '[-u] [-x]'; exit 1;
          fi
  fi
done

cd /usr/spool/gopher/travel

# Perform the travel using "gtravel", and gzip the result

if [ "$OPT_u" = -u ]; then
  rm world.travel.gz
  gtravel -k world.kill  -p "1/Other Gopher and Information Servers/all" \
          -d 1  gopher.micro.umn.edu 70 \
      | gzip > world.travel.gz
fi

# Generate the pretty travel listing

zcat world.travel.gz | gpretty -d 3 -h gopher.micro.umn.edu > world.pretty

# Update the old travel

zcat world.gtimes.gz world.travel.gz | gtimes $OPT_x > world.new && \
  (mv world.gtimes.gz world.bak.gz; mv world.new world.gtimes; \
   gzip world.gtimes)

# Use the following instead if you choose NOT to compress the *.gtimes file.

#(cat world.gtimes; zcat world.travel.gz ) | gtimes $OPT_x > world.new && \
#  (mv world.gtimes world.bak; mv world.new world.gtimes; \
#   rm world.bak.gz; gzip world.bak)
