#!/bin/sh
#
# This is to be used over an arbitrary gopher server.  It puts some load
# on the server, so you should reserve it to early morning or such.
# If you are indexing a server that is not your own, consider early
# Sunday mornings.
#
# Remember to create an empty myserver.gtimes.gz for the first run.
#
PATH=/usr/local/bin:/bin:/usr/bin:/usr/ucb:/usr/new/mh:/usr/spool/archive/bin
export PATH
cd /usr/spool/gopher/travel

# Perform the travel itself.

gtravel -k myserver.kill my.server.address 70 | gzip > myserver.travel.gz


# Generate a pretty listing of the travel.  See the options for gpretty.

zcat myserver.travel.gz | gpretty -d 2 -h my.server.address > myserver.pretty


# Update the old memories.

zcat myserver.gtimes.gz myserver.travel.gz | gtimes -x > myserver.new && \
  (mv myserver.gtimes.gz myserver.bak.gz; mv myserver.new myserver.gtimes; \
   gzip myserver.gtimes)
