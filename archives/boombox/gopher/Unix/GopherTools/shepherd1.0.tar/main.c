#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "socket.h"


void
main(argc,argv)
int argc;
char **argv;
{
int uid;

uid = getuid();
if(uid != 0)
	{
	printf("Sorry, you must be root to run this program.\n");
	exit(1);
	};

ParseRCLocal();
}
