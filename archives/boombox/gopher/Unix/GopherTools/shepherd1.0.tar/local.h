#define RCLOCAL "/etc/rc.local"
#define LOGFILE "/usr/local/adm/shepherd/shepherd.log"

#define GOPHER	1
#define WAIS	2
#define SUBMIT	3
#define HTTP	4
#define JUGHEAD 5


typedef struct serverlist {
	char *name;
	int id;
	int port;
	struct serrverlist *next;
} SERVERLIST;

SERVERLIST SERVERITEM[]={
{"gopherd",GOPHER,70},
{"gopherd+",GOPHER,70},
{"waisserver",WAIS,210},
{"submitd",SUBMIT,9000},
{"httpd",HTTP,80},
{"jughead",JUGHEAD,3000},
NULL};

#define SERVERTYPES 6


struct serv {
char name[256];
int id;
int port;
};

