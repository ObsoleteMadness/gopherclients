#include <stdio.h>

char *getBlankedString(oneline,field)
char *oneline;
int field;
{
static char buff[1024];
int i;
int j,x;
 
for(; *oneline == ' ' && *oneline != '\n';*oneline++);
 
for(j = 2; j < field+1; j++)
        {
        for(; (*oneline !=' ')  && (oneline); *oneline++);
      	for(; (*oneline == ' ') && (oneline) ; *oneline++);
        };
 
 
for(i = 0; *oneline != ' ' && *oneline != '\n'  ; i++,*oneline++)
        {
        buff[i] = *oneline;
        };
 
for(x = i; x < 26; x++)
        buff[x] = ' ';
 
buff[i] = '\0';
 
return buff;
}
 
char *getDelimitedString(oneline,character,field)
char *oneline;
char character;
int field;
{
static char buff[1024];
int i;
int j,x;
 
for(; *oneline == character && *oneline != '\n';*oneline++);
 
for(j = 2; j < field+1; j++)
        {
        for(; (*oneline !=character)  && (oneline); *oneline++);
      	for(; (*oneline == character) && (oneline) ; *oneline++);
        };
 
 
for(i = 0; *oneline != character && *oneline != '\n'  ; i++,*oneline++)
        {
        buff[i] = *oneline;
        };
 
for(x = i; x < 1023; x++)
        buff[x] = ' ';
 
buff[i] = '\0';
 
return buff;
}
