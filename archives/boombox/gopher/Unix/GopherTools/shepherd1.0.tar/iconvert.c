#include <stdio.h>

/**********************************************************************/
int i_convert(string)
char string[];
{
  int count,sign,amount,digit;

  count = 0;
  sign = 1;
  while (string[count])
      if (string[count++] == '-') sign = -1;
  count = amount =0;
  while (string[count])
   {

     if (string[count] >= '0' && string[count] <= '9')
	{  digit = string[count] - '0';
	   amount *= 10;
	   amount += digit;
	}
   /*   else {
	    printf("\n  String Not Numeric Type \n");
	    exit(1);
	    }*/
    count++;
   }
 amount *= sign;
 return (amount);
}    

/* ----------------------------------------------------------------- */
