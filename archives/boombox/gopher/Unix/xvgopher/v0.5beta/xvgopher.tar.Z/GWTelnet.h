//
// GWTelnet.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class deals with the getting and saving of ASCII files from
// a gopher server.
//
#ifndef	_GWTelnet_h_
#define	_GWTelnet_h_

#include "GWindow.h"

class GWTelnet : public GWindow
{
public:
							GWTelnet(Frame par);
	virtual int				open(Response *resp);
private:
};

#endif	_GWTelnet_h_
