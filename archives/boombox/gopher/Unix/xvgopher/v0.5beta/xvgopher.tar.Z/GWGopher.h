//
// GWGopher.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class creates a popup window which asks for details about a new gopher
// server.  After this is information is supplied, it will start a new
// main frame for that gopher server.
//
#ifndef	_GWGopher_h_
#define	_GWGopher_h_

#include "GWindow.h"

class GWGopher : public GWindow
{
public:
							GWGopher(Frame par);
	int						open(Response *resp);
private:
	static void				start_proc(Panel_item, Event *);

	Panel_item				server;
	Panel_item				port;
};

#endif	_GWGopher_h_
