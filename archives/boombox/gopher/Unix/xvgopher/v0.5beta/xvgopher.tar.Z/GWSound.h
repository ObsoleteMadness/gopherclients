//
// GWSound.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class deals with the getting and saving of ASCII files from
// a gopher server.
//
#ifndef	_GWSound_h_
#define	_GWSound_h_

#include "GWDownload.h"

class GWSound : public GWDownload
{
public:
							GWSound(Frame par);
};

#endif	_GWSound_h_
