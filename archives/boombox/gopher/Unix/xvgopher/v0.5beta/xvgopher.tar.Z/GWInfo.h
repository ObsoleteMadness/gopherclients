//
// GWInfo.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class defines a window which shows information about an item.
// The only things which is passed to this window is a Response.  Everything can
// be deduced from there.
//
#ifndef	_GWInfo_h_
#define	_GWInfo_h_

#include "xvgopher.h"
#include "GWindow.h"
#include "Response.h"

class GWInfo : public GWindow
{
public:
							GWInfo(Frame par);
	int						open(Response *);
private:
};

#endif	_GWInfo_h_
