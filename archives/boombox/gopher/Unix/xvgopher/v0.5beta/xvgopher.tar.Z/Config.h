//
// Config.h
//
// This class deals with configuration.  All configurable options are kept in this class
//
#ifndef	_Config_h_
#define	_Config_h_

#include "List.h"


class Config
{
public:
	//
	// Constructor
	//
							Config();

	//
	// Configuration file access
	//
	void					read();
	int						write();

	//
	// Configuration parameters.  These are directly accessible to make it easier.
	//
	List					bookmarks;
	String					server;
	int						port;
private:
};

#endif	_Config_h_
