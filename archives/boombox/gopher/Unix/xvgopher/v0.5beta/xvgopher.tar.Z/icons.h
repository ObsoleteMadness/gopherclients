//
// icons.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
#ifndef	_icons_h_
#define	_icons_h_

Server_image get_image(char type);

#endif	_icons_h_
