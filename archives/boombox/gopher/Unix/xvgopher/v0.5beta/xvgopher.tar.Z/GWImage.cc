//
// GWImage.cc
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// Implementation of the GWImage class
//
#include "GWImage.h"
#include "xvgopher.h"


//***************************************************************************
// GWImage::GWImage(Frame par)
//
GWImage::GWImage(Frame par) : GWDownload(par, GWDownload::BINARY, "View", preferences.get_image_filter())
{
}


