//
// GWPref.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class deals with the interface between the preferences and the window which allows
// the preferences to be changed.
//
#ifndef	_GWPref_h_
#define	_GWPref_h_

#include "GWindow.h"

class GWPref : public GWindow
{
public:
	//
	// Constructor
	//
							GWPref(Frame);
							~GWPref();
	int						open(Response *);
	void					show();
private:
	//
	// Remember where items are so we can reference them!
	//
	Panel_item				choices;
	Panel_item				play;
	Panel_item				image;
	Panel_item				print;
	Panel_item				mail;
	Panel_item				telnet;

	//
	// Call back routines
	//
	static void				done_proc(Frame);
	static void				apply(Panel_item, Event *);
};


extern GWPref	*gwpref;

#endif	_GWPref_h_
