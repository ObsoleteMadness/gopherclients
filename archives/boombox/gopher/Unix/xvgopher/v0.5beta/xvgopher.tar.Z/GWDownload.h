//
// GWDownload.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class deals with the getting and saving of ASCII files from
// a gopher server.
//
#ifndef	_GWDownload_h_
#define	_GWDownload_h_

#include "GWindow.h"

class GWDownload : public GWindow
{
public:
							GWDownload(Frame par, int type, char *btn, char *btncmd);
							GWDownload(Frame par, int type);
	int						open(Response *resp);
	void					display();
	enum
	{
		BINARY,
		ASCII,
	};
protected:
	static void				bin_save_notify(Panel_item, Event *);
	static void				bin_cancel_notify(Panel_item, Event *);
	static void				bin_other_notify(Panel_item, Event *);
	static Panel_setting	bin_text_notify(Panel_item, Event *);
private:
	int						type;
	char					*button;			// Label of the optional button
	char					*button_command;	// Command to execute when button pressed
};

#endif	_GWDownload_h_
