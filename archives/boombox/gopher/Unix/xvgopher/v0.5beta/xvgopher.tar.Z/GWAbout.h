//
// GWAbout.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class produces a popup window describing the who, what, and where of
// xvgopher.
//
#ifndef	_GWAbout_h_
#define	_GWAbout_h_

#include "GWindow.h"

class GWAbout : public GWindow
{
public:
							GWAbout(Frame par);
	int						open(Response *resp);
private:
	static void				done_proc(Frame);
	static void				dismiss_proc(Panel_item, Event *);
	static Notify_value		panel_events(Xv_window, Event *, Notify_arg, Notify_event_type);
};

#endif	_GWAbout_h_
