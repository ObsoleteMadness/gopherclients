//
// GWBinary.cc
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// Implementation of the GWBinary class
//
#include "GWBinary.h"
#include "xvgopher.h"
#include "cursor.h"
#include <fcntl.h>
#include <unistd.h>


//***************************************************************************
// GWBinary::GWBinary(Frame par)
//
GWBinary::GWBinary(Frame par) : GWDownload(par, GWDownload::BINARY)
{
}


