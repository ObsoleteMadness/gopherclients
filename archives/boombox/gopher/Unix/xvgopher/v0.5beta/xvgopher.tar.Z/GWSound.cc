//
// GWSound.cc
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// Implementation of the GWSound class
//
#include "GWSound.h"
#include "xvgopher.h"


//***************************************************************************
// GWSound::GWSound(Frame par)
//
GWSound::GWSound(Frame par) : GWDownload(par, GWDownload::BINARY, "Play", preferences.get_play_filter())
{
}
