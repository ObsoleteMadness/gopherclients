//
// Prototypes
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
void frame_busy(Frame);
void frame_unbusy(Frame);
Server_image get_gopher(int);
