//
// GWImage.h
//
// (c) Copyright 1993, San Diego State University -- College of Sciences
//       (See the COPYRIGHT file for more Copyright information)
//
// This class deals with the getting and saving of ASCII files from
// a gopher server.
//
#ifndef	_GWImage_h_
#define	_GWImage_h_

#include "GWDownload.h"

class GWImage : public GWDownload
{
public:
							GWImage(Frame par);
};

#endif	_GWImage_h_
