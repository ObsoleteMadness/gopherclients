FILE    *Specialfile(int sockfd, FILE *fp, char *pathname);
int      Specialclose(FILE *fp);
