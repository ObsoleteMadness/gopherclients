/*
 * The minor and major version numbers...
 */

#define GOPHER_MAJOR_VERSION "2"
#define GOPHER_MINOR_VERSION "3"

#define PATCHLEVEL 0
