/* sc_extendP.h
   private header file for gopher item subclass: extend type */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/

#include "util.h"
#include "sc_extend.h"
#include "osdep.h"

char	prefixExtend [ PREFIX_LEN ];


accessList	extendHostList=NULL;

/* ----- subclass record definition ----- */

scInfo	extendSubclass = {
		"non-internal item",
		prefixExtend,
		&extendHostList,
		GIExtend_access,
		GI_copyToFile,
		copyTypeBinaryEOF,
		GIExtend_process,
		GIExtend_init,
		GI_done,
		GI_restart
	};

/* ----- extended types parameters ----- */

typedef struct extTypeValueStruct {
	char	type;			/* which type it applies to */
	char	*execCommand;		/* command to execute for this type */
	BOOLEAN	wait;			/* don't go on until done */
	BOOLEAN	failed;		/* command failed before */
	PID_TYPE pid;			/* PID of active process */
	struct extTypeValueStruct *next;
} extTypeValue;
