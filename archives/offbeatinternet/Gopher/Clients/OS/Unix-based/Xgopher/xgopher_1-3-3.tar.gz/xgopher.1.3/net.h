/* net.n
   header file for net.c */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/

#include "gopher.h"

int connectToSocket(
#ifdef PROTO
	char *,		/* host */
	int		/* port */
#endif
);

void networkError(
#ifdef PROTO
	int,		/* gfd */
	char *,		/* host */
	int 		/* port */
#endif
);

int readn(
#ifdef PROTO
	int,		/* fd */
	char *,		/* ptr */
	int		/* nbytes */
#endif
);

int writen(
#ifdef PROTO
	int,		/* fd */
	char *,		/* ptr */
	int		/* nbytes */
#endif
);

int writestring(
#ifdef PROTO
	int,		/* fd */
	char *		/* stringptr */
#endif
);

int readline(
#ifdef PROTO
	int,		/* fd */
	char *,		/* ptr */
	int		/* maxlen */
#endif
);

int readfield(
#ifdef PROTO
	int,		/* fd */
	char *,		/* ptr */
	int		/* maxlen */
#endif
);

int readDelim(
#ifdef PROTO
	int,		/* fd */
	char *,		/* ptr */
	int,		/* maxlen */
	char	 	/* delim */
#endif
);

void ZapCRLF(
#ifdef PROTO
	char *		/* inputline */
#endif
);
