/* sc_extend.h
   gopher item subclass: extended type */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/

#include "gopher.h"


#define EXT_CLASS	"Extend"

extern scInfo  extendSubclass;

/* ----- subclass function definitions ----- */

void	GIExtend_init(
);

BOOLEAN GIExtend_process(
#ifdef PROTO
		gopherItemP		/* gi */
#endif
	);

BOOLEAN GIExtend_access(
#ifdef PROTO
		gopherItemP		/* gi */
#endif
	);
