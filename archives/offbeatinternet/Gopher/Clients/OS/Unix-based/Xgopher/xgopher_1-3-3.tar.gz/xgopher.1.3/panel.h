/* panel.h
   header file for panel.c, including some defines */

     /*---------------------------------------------------------------*/
     /* Xgopher        version 1.3     08 April 1993                  */
     /*                version 1.2     20 November 1992               */
     /*                version 1.1     20 April 1992                  */
     /*                version 1.0     04 March 1992                  */
     /* X window system client for the University of Minnesota        */
     /*                                Internet Gopher System.        */
     /* Allan Tuchman, University of Illinois at Urbana-Champaign     */
     /*                Computing and Communications Services Office   */
     /* Copyright 1992, 1993 by                                       */
     /*           the Board of Trustees of the University of Illinois */
     /* Permission is granted to freely copy and redistribute this    */
     /* software with the copyright notice intact.                    */
     /*---------------------------------------------------------------*/


#ifndef PANEL_H
#define PANEL_H


#define BS_fetch	  01
#define BS_copy		  02
#define BS_previous	  04
#define BS_unmark	 010
#define BS_unmarkAll	 020
#define BS_loadMarks	 040
#define BS_saveMarks	0100
#define BS_info		0200
#define BS_mark		0400
#define BS_none		0
#define BS_changeSelected	(BS_fetch|BS_copy|BS_info|BS_mark|BS_unmark)
#define BS_all		0777

#define LS_infoItem    01000
#define LS_markItem    02000
#define LS_items       03000
/*
#define BS_all		(BS_fetch | BS_copy | BS_previous | BS_unmark | \
			 BS_unmarkAll | BS_loadMarks | BS_saveMarks | \
			 BS_info | BS_mark)
*/

typedef	int	buttonSet;


String		infoItemLabel, infoDirLabel, markItemLabel, markDirLabel;

void		checkButtonState(
#ifdef PROTO
	buttonSet	/* which */
#endif
);

gopherItemP
whichItemSelected(
);

void		markProc(
#ifdef PROTO
	Widget,		/* w */
	XtPointer,	/* client_data */
	XtPointer	/* call_data */
#endif
);

#endif /* PANEL_H */
