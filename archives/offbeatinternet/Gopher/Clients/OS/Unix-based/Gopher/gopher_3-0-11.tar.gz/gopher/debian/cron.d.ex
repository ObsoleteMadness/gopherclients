#
# Regular cron jobs for the gopher package
#
0 4	* * *	root	gopher_maintenance
