/* cso.h
 * Written by David Allen <s2mdalle@titan.vcu.edu>
 * Simple prototypes for functions in cso.c
 */

#define CSO_H 1

void do_cso(GopherStruct *ZeGopher);
