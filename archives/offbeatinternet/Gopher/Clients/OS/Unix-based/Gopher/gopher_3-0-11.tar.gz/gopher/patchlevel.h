/*
 * The minor and major version numbers...
 */

#define GOPHER_MAJOR_VERSION "3"
#define GOPHER_MINOR_VERSION "0"
#define PATCHLEVEL 11
#define GOPHER_NICKNAME "FurryTerror"
