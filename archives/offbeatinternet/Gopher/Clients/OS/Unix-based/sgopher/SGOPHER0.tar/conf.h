/*
	HOST .......... default host
	PORT .......... default port
	GOPHADM ....... name of gopher help contact
	GOPHPHN ....... phone number for gopher help
	GOPHADDR ...... address for bounced mail
	GOVCOMP ....... define if you want COMSEC warning on startup
	LOGFILE ....... define file name for logging information
			if run under inetd
	TIMEOUT ....... number of seconds for user input timeout
			undefine if you don't want timeout checking
	VMS ........... (*) should already be defined for VMS
	ULTRIX ........ define for Ultrix
	NEED_STRDUP ... (*) if strdup not in string library
	KRC ........... (*) defined for old style function headers

	* = should be defined automatically
*/
#define HOST "ccfiris"
#define PORT "70"
#define GOPHADM "Sean Fuller"
#define GOPHPHN "7560"
#define GOPHADDR "gopher@ccfiris"
/*
	I used an if statement here because it is not run under inetd
	on our VMS and ULTRIX systems.
*/
#ifndef VMS
#ifndef ULTRIX
#define GOVCOMP
#define LOGFILE "/usr1/people/c60201/gopher/sgopher.log"
#define TIMEOUT 30
#endif
#endif

/*
	Hopefully, you won't have to change anything below here.
	This stuff is for determining changes in code by architecture.
*/
#ifdef VMS
#define NEED_STRDUP
#endif

#ifdef ULTRIX
#define NEED_STRDUP
#define KRC
#endif
