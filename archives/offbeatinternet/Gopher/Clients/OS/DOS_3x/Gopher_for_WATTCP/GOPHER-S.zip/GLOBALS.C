#define EXTERN
#include "gopher.h"
